function out = ValidateFastScheme()
% ValidateFastScheme
% Monte-Carlo: 随机抽参数 -> TM仿真生成EPSC -> 二阶矩算法反演 -> 对比分布
%
% 依赖：
%   - SimulateEPSCPeaks.m（内部调用 GenerateSimuEPSC） 
%   - estimate_synapse_params.m
%
% 建议放在 Validation/ 目录下

clc; close all;

%% ----------------------- 1) 全局设置 -----------------------
rng(0);

cfg.num_trials   = 300;     % Monte-Carlo 次数（每次抽一组真参数）
cfg.num_stim     = 10;      % 脉冲数 T
cfg.num_sweeps   = 200;     % 每组参数下的重复次数（reps）
cfg.stim_freq    = 50;      % Hz（也可以扩展成多频率循环）
cfg.noise_std    = 5;       % EPSC测量噪声标准差（与GenerateSimuEPSC一致）
cfg.use_lognorm  = true;    % tau 常用 log 采样更合理

% 参数采样范围（你们可按生理范围/论文设定修改）
range.q          = [5, 50];        % pA
range.N          = [20, 200];      % release sites
range.U          = [0.02, 0.8];    % 0~1
range.tau_rec    = [50, 1500];     % ms
range.tau_facil  = [50, 8000];     % ms

%% ----------------------- 2) 预分配存储 -----------------------
T = cfg.num_stim;
K = cfg.num_trials;

q_true  = nan(K,1);  N_true  = nan(K,1);  U_true  = nan(K,1);
tr_true = nan(K,1);  tf_true = nan(K,1);

q_hat   = nan(K,1);  N_hat   = nan(K,1);
p_true  = nan(K,T);  p_hat   = nan(K,T);
rmse    = nan(K,1);

failMask = false(K,1);

%% ----------------------- 3) Monte-Carlo 主循环 -----------------------
for k = 1:K
    % ---- 3.1 抽样一组“真参数”
    params = struct();
    params.q          = sample_uniform(range.q);
    params.N          = round(sample_uniform(range.N));
    params.U          = sample_uniform(range.U);

    if cfg.use_lognorm
        params.tau_rec   = sample_log_uniform(range.tau_rec);
        params.tau_facil = sample_log_uniform(range.tau_facil);
    else
        params.tau_rec   = sample_uniform(range.tau_rec);
        params.tau_facil = sample_uniform(range.tau_facil);
    end

    params.stim_freq  = cfg.stim_freq;
    params.num_stim   = cfg.num_stim;
    params.noise_std  = cfg.noise_std;
    params.num_sweeps = cfg.num_sweeps;

    % ---- 存真值
    q_true(k)  = params.q;
    N_true(k)  = params.N;
    U_true(k)  = params.U;
    tr_true(k) = params.tau_rec;
    tf_true(k) = params.tau_facil;

    try
        % ---- 3.2 用 TM 模型生成一组仿真 EPSC 峰值矩阵
        % SimulateEPSCPeaks: epsc_peaks 是 [num_sweeps x num_stim]
        simRes = SimulateEPSCPeaks(params);
        epsc_peaks = simRes.epsc_peaks;  % sweeps x T

        % 真值释放概率（理论 pi = R*u），同样是 sweeps x T
        % 这里取 sweep 维平均作为“真 p_i”（也可取第一条 sweep 的 pi）
        pi_mean = mean(simRes.release_prob, 1);  % 1 x T

        % ---- 3.3 调用你们的二阶矩反演算法
        data = epsc_peaks';  % 转成 [T x sweeps]，符合 estimate_synapse_params 输入
        est = estimate_synapse_params(data, cfg.noise_std);

        % ---- 3.4 存反演结果
        q_hat(k) = est.q;
        N_hat(k) = est.N;
        p_hat(k,:) = est.p(:)';
        p_true(k,:) = pi_mean(:)';   % 作为“真 p_i”参考
        rmse(k)  = est.rmse;

    catch ME
        failMask(k) = true;
        warning("Trial %d failed: %s", k, ME.message);
    end
end

%% ----------------------- 4) 清理失败样本 -----------------------
valid = ~failMask & isfinite(q_hat) & isfinite(N_hat) & q_hat>0 & N_hat>0;
fprintf("Valid trials: %d / %d\n", sum(valid), K);

q_true = q_true(valid); N_true = N_true(valid);
q_hat  = q_hat(valid);  N_hat  = N_hat(valid);
p_true = p_true(valid,:); p_hat = p_hat(valid,:);
rmse   = rmse(valid);

%% ----------------------- 5) 统计与可视化 -----------------------
out = struct();
out.q_true = q_true; out.q_hat = q_hat;
out.N_true = N_true; out.N_hat = N_hat;
out.p_true = p_true; out.p_hat = p_hat;
out.rmse   = rmse;

% ---- 5.1 q / N 的“分布对比”（估计分布 + 真值分布）
figure('Name','q and N distribution');
subplot(2,2,1);
histogram(q_true, 30); hold on; histogram(q_hat, 30);
xlabel('q (pA)'); ylabel('count'); title('q: true vs estimated');
legend('true','estimated'); grid on;

subplot(2,2,2);
histogram(N_true, 30); hold on; histogram(N_hat, 30);
xlabel('N'); ylabel('count'); title('N: true vs estimated');
legend('true','estimated'); grid on;

% ---- 5.2 散点：看偏差与相关性
subplot(2,2,3);
scatter(q_true, q_hat, 12, 'filled'); hold on;
plot([min(q_true) max(q_true)], [min(q_true) max(q_true)], 'k--');
xlabel('q true'); ylabel('q estimated'); title('q: scatter');
axis tight; grid on;

subplot(2,2,4);
scatter(N_true, N_hat, 12, 'filled'); hold on;
plot([min(N_true) max(N_true)], [min(N_true) max(N_true)], 'k--');
xlabel('N true'); ylabel('N estimated'); title('N: scatter');
axis tight; grid on;

% ---- 5.3 p_i 的误差分布（按刺激序号）
p_err = p_hat - p_true;
figure('Name','p_i error by stimulus index');
boxchart(p_err);
xlabel('Stimulus index i'); ylabel('p_hat(i) - p_true(i)');
title('Release probability error across pulses');
grid on;

% ---- 5.4 简单数值总结
fprintf("\nq: bias = %.3f, relRMSE = %.3f\n", ...
    mean(q_hat-q_true), sqrt(mean((q_hat-q_true).^2))/mean(q_true));
fprintf("N: bias = %.3f, relRMSE = %.3f\n", ...
    mean(N_hat-N_true), sqrt(mean((N_hat-N_true).^2))/mean(N_true));
fprintf("median rmse(mu recon) = %.3f\n", median(rmse));

end

%% ----------------------- helper: uniform sampling -----------------------
function x = sample_uniform(rng2)
x = rng2(1) + rand()*(rng2(2)-rng2(1));
end

%% ----------------------- helper: log-uniform sampling -------------------
function x = sample_log_uniform(rng2)
% rng2 in linear domain, sample log-uniform between [min,max]
a = log(rng2(1)); b = log(rng2(2));
x = exp(a + rand()*(b-a));
end
