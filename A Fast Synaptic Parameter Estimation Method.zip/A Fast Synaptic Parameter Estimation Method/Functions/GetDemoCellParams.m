function params = GetDemoCellParams()
%---------------计算参数值
params.q          = 10;
params.N          = 100;
params.U          = 0.05;
params.tau_rec    = 300;
params.tau_facil  = 1500;
params.stim_freq  = 50;
params.num_stim   = 10;
params.noise_std  = 5;
params.num_sweeps = 30;
end