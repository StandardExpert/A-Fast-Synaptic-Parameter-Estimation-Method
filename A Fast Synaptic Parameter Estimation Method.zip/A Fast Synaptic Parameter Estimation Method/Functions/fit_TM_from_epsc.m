function result = fit_TM_from_epsc(epsc, freqList)
% fit_TM_from_epsc  拟合 Tsodyks–Markram 短时突触可塑性模型参数（带范围约束 + 多初值）
%
%   输入：
%     epsc     : [nTrials x nPulses x nFreq]  (EPSC 峰值)
%     freqList : [1 x nFreq]  (Hz)
%
%   输出：
%     result.A          : 最大突触效能 A
%     result.U          : 基础利用率 U
%     result.tau_rec    : 资源恢复时间常数 tau_rec (秒)
%     result.tau_facil  : 易化时间常数 tau_facil (秒)
%     result.modelEPSC  : [nPulses x nFreq]，拟合模型 EPSC
%     result.dataEPSC   : [nPulses x nFreq]，实验数据（平均后）
%     result.freqList   : 频率列表
%     result.fval       : 最佳目标函数值（越小越好）
%     result.exitflag   : fmincon 的退出标志（>0 通常表示正常收敛）

%--------------------------------------------------------------------------
%                         1. 基本尺寸与预处理
%--------------------------------------------------------------------------
if nargin < 2
    error('需要输入 epsc 和 freqList');
end

[nTrials, nPulses, nFreq] = size(epsc);

if length(freqList) ~= nFreq
    error('freqList 的长度必须等于 epsc 的第三维 nFreq');
end

% trial 维求平均：得到 [nPulses x nFreq]
dataEPSC = squeeze(mean(epsc, 1, 'omitnan'));

% 防止 squeeze 把单频率数据挤成行向量
if nFreq == 1
    dataEPSC = reshape(dataEPSC, [nPulses, nFreq]);
end

% 拉直成列向量
dataVec = dataEPSC(:);
dataAbs = abs(dataVec);
dataAbs(dataAbs == 0) = 1e-12;  % 避免除零

% 振幅尺度，用于给 A 的合理范围
ampMax = max(abs(dataVec));
if ampMax == 0
    error('数据全为 0，无法拟合');
end

%--------------------------------------------------------------------------
%                       2. 参数范围（单位：秒）
%--------------------------------------------------------------------------
% A 根据数据幅度自适应
A_min = 0.1 * ampMax;
A_max = 10  * ampMax;

% U 范围（0~1 内合理，不要太接近 0 或 1）
U_min = 0.01;
U_max = 0.9;

% tau_rec：20 ms ~ 1.5 s
tau_rec_min = 0.02;   % s
tau_rec_max = 1.5;    % s

% tau_facil：50 ms ~ 8 s
tau_facil_min = 0.05; % s
tau_facil_max = 8.0;  % s

lb = [A_min,   U_min,       tau_rec_min,   tau_facil_min];
ub = [A_max,   U_max,       tau_rec_max,   tau_facil_max];

%--------------------------------------------------------------------------
%                           3. 多组初值设置
%--------------------------------------------------------------------------
x0_list = [];

% 典型易化型（文献：U~0.03, trec~0.3s, tfacil~1.8s）
x0_list(end+1, :) = [0.8*ampMax, 0.03, 0.3, 1.8];

% 典型抑制型（文献：U~0.5, trec~0.8s, 几乎无易化）
x0_list(end+1, :) = [0.8*ampMax, 0.5, 0.8, 0.05];

% 稍高易化
x0_list(end+1, :) = [1.2*ampMax, 0.08, 0.4, 3.0];

% 稍低利用率
x0_list(end+1, :) = [0.5*ampMax, 0.02, 0.2, 1.0];

% 再加几组随机初值，覆盖更大范围
nRand = 4;
for ii = 1:nRand
    A0   = A_min   + rand*(A_max - A_min);
    U0   = U_min   + rand*(U_max - U_min);
    tr0  = tau_rec_min   + rand*(tau_rec_max - tau_rec_min);
    tf0  = tau_facil_min + rand*(tau_facil_max - tau_facil_min);
    x0_list(end+1, :) = [A0, U0, tr0, tf0];
end

%--------------------------------------------------------------------------
%                       4. 构造目标函数（带物理参数）
%--------------------------------------------------------------------------
% 目标函数：所有点相对误差平方和
objFun = @(x) objective_TM_phys(x, dataVec, dataAbs, nPulses, freqList);

% fmincon 选项
opts = optimoptions('fmincon', ...
    'Display', 'off', ...           % 如需看迭代过程改成 'iter'
    'Algorithm', 'interior-point', ...
    'MaxIterations', 500, ...
    'MaxFunctionEvaluations', 5000, ...
    'OptimalityTolerance', 1e-6, ...
    'StepTolerance', 1e-8);

%--------------------------------------------------------------------------
%                     5. 多初值 + fmincon，全局选最优
%--------------------------------------------------------------------------
bestFval = inf;
bestX    = [];
bestFlag = [];

for ii = 1:size(x0_list, 1)
    x0 = x0_list(ii,:);

    % 把初值投影到 [lb, ub] 范围内（防止手动给的超界）
    x0 = max(x0, lb);
    x0 = min(x0, ub);

    try
        [xOpt, fval, exitflag] = fmincon(objFun, x0, [], [], [], [], lb, ub, [], opts);
    catch ME
        warning(ME.identifier,'fmincon 失败：%s', ME.message);
        continue;
    end

    if fval < bestFval && exitflag > 0   % 只接受正常收敛的结果
        bestFval = fval;
        bestX    = xOpt;
        bestFlag = exitflag;
    end
end

if isempty(bestX)
    error('所有初值都没有成功收敛，请检查数据或放宽范围。');
end

A         = bestX(1);
U         = bestX(2);
tau_rec   = bestX(3);
tau_facil = bestX(4);

%--------------------------------------------------------------------------
%                       6. 用最优参数生成拟合序列
%--------------------------------------------------------------------------
modelVec = simulate_TM_phys(bestX, nPulses, freqList);
modelEPSC = reshape(modelVec, [nPulses, nFreq]);

%--------------------------------------------------------------------------
%                              7. 打包输出
%--------------------------------------------------------------------------
result.A         = A;
result.U         = U;
result.tau_rec   = tau_rec;
result.tau_facil = tau_facil;
result.fval      = bestFval;
result.exitflag  = bestFlag;
result.modelEPSC = modelEPSC;
result.dataEPSC  = dataEPSC;
result.freqList  = freqList;
end

%==========================================================================
%           下面是辅助函数：目标函数（物理参数版本）与模型仿真
%==========================================================================

function E = objective_TM_phys(x, dataVec, dataAbs, nPulses, freqList)
% x = [A, U, tau_rec, tau_facil] (全为物理量，已由 fmincon 保证在合理范围内)

% 模型生成的 EPSC 向量
modelVec = simulate_TM_phys(x, nPulses, freqList);

% 相对误差
relErr = (modelVec - dataVec) ./ dataAbs;

% 误差标量：平方和
E = sum(relErr.^2);
end

