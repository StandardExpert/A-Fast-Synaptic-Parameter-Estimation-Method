function results = SimulateEPSCPeaks(params)
% ============================================================
% SimulateEPSCPeaks
% ------------------------------------------------------------
% 仿真在给定刺激频率和突触参数下：
%   - 每次电刺激后的 EPSC 峰值
%   - 对应释放概率
%   - 多 sweep 统计量（用于 moment 计算验证）
%
% 与已有 GenerateSimuEPSC / MT 模型完全一致
% ============================================================

%% ----------- 读取参数 -----------
q          = params.q;            % quantal size (pA)
N          = round(params.N);     % release sites
U          = params.U;            % baseline utilization
tau_rec    = params.tau_rec;      % ms
tau_facil  = params.tau_facil;    % ms
stim_freq  = params.stim_freq;    % Hz
num_stim   = params.num_stim;     % pulses per train
noise_std  = params.noise_std;    % measurement noise
num_sweeps = params.num_sweeps;   % repeated trials

%% ----------- 初始化输出 -----------
epsc_mat = zeros(num_sweeps, num_stim);
pi_mat   = zeros(num_sweeps, num_stim);

%% ----------- 多 sweep 仿真 -----------
for s = 1:num_sweeps
    [epsc, pi] = GenerateSimuEPSC( ...
        q, N, U, stim_freq, tau_rec, tau_facil, num_stim, noise_std);
    
    epsc_mat(s,:) = epsc;
    pi_mat(s,:)   = pi;
end

%% ----------- 统计量（用于 moment 方法）-----------
mu  = mean(epsc_mat, 1);     % μ_i
var_eps = var(epsc_mat, 0, 1);
cov_eps = cov(epsc_mat);

%% ----------- 打包结果 -----------
results.epsc_peaks   = epsc_mat;   % 每 sweep 的 EPSC 峰值
results.release_prob = pi_mat;     % p_i = R*u
results.mu           = mu;
results.var          = var_eps;
results.cov          = cov_eps;

end
