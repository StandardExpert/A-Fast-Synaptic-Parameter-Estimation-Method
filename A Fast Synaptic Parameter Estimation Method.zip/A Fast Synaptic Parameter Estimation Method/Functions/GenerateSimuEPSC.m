function [epsc_data,pi] = GenerateSimuEPSC(q,N,U,stim_freq,tau_rec,tau_facil,num_stim,noise_std)
%% ===============================
%   Markram–Tsodyks Dynamic Synapse
%   EPSC Simulator with R*u Release Probability
%   Author: ChatGPT鸡皮提，已检查验证
%   StandardExpert 20251122
% ===============================
% Fuhrmann et al., 2002, J Neurophysiology（Coding of temporal information by activity-dependent synapses）
% % ---- Debug参数 ----
% q = 20;             % quantal size (pA)
% N = 100;             % number of release sites∈[0.012–0.086]
% U = 0.1;            % baseline utilization (U 参数)
% tau_rec = 300;      % recovery time constant (ms)∈[104,694]
% tau_facil = 1500;    % facilitation time constant (ms)∈[550,3044]
% 
% % ---- 刺激参数 ----
% stim_freq = 20;           % stimulation frequency (Hz)
% num_stim = 100;           % number of stimuli
% 
% % ---- 噪声 ----
% noise_std = 5;     % measurement noise (pA)

% ---- 变量初始化 ----
ISI = 1000 / stim_freq;   % inter-spike interval (ms)
R = 1;             % all resources available at start
u = U;             % initial utilization
epsc_data = zeros(1, num_stim);

% ---- 仿真循环 ----
pi = zeros(1,num_stim);
for ii = 1:num_stim

    % ---- Step 1: 计算本次刺激释放概率 p = R*u ----
    p_release = R * u;
    pi(ii) = p_release;
    % ---- Step 2: 随机释放数（服从二项分布）----
    n_released = binornd(N, p_release);
    % n_released = N*p_release;
    % ---- Step 3: EPSC = q * released vesicles ----
    epsc = q * n_released;

    % ---- 添加测量噪声 ----
    if noise_std~=0
        epsc = epsc + normrnd(0, noise_std);
    end
    % ---- 保存数据 ----
    epsc_data(ii) = epsc;


    % % 从第 k 个脉冲后演化到下一个脉冲前
    % % 易化变量 u 的衰减 + 跳增
    % u_decay = u * exp(-ISI / tau_facil);
    % u  = u_decay + U * (1 - u_decay);
    % 
    % % 资源 R：释放 u_next 后，再在 dt 内恢复
    % R_depleted = R * (1 - u);
    % R     = 1 - (1 - R_depleted) * exp(-ISI / tau_rec);
    % ---- Step 4: 按 Markram–Tsodyks 模型更新 u ----
    u = u * exp(-ISI / tau_facil) + U * (1 - u * exp(-ISI / tau_facil));

    % ---- Step 5: 更新 R ----
    R = R * (1 - u) * exp(-ISI / tau_rec) ...
        + (1 - exp(-ISI / tau_rec));
end


end