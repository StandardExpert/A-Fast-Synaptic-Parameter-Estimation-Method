function results = estimate_synapse_params(data, sigma_noise_std)
% data: [numPulses × numReps]
% sigma_noise_std: noise sigma (scalar)

%--------------- debug
% dataStru = load("E:\MATLAB Code\short-term synaptic plasticity\VM outputs\Ctrl\20250826_Ctrl_slice1_cell1_20Hz.mat");
% data = dataStru.amp;
% sigma_noise_std = 5;


[numPulses, ~] = size(data);

%--------------- 1. 计算一阶矩二阶矩(moments)
muMat       = mean(data, 2,"omitmissing");      % μ_i.
sigma_eta2  = sigma_noise_std^2;                %σ_η²
covMat      = cov(data',0,"partialrows");
% varMat      = var(data,0,2,"omitnan");
varMat      = diag(covMat);

%--------------- 2. 计算中间项 F_ij = Var(A_i) − μ_i/μ_j * Cov(A_i,A_j) − σ_η²
F = varMat - muMat*(1./muMat').*covMat - sigma_eta2;

% 最土的循环写法
% F = zeros(numPulses, numPulses);
% for i = 1:numPulses
%     for j = 1:numPulses
%         F(i,j) = varMat(i) ...
%                  - (muMat(i)/muMat(j)) * covMat(i,j) ...
%                  - sigma_eta2;
%     end
% end

%--------------- 3. 计算 R-hat = sigma_q² / q² = mean(CovA(i,j)/(μ_i μ_j)), i≠j
covMask = ~eye(numPulses);
Rlist = covMat ./ (muMat * muMat');
secureMask = ~isnan(Rlist) & ~isinf(Rlist);%确保安全值，防止极端离谱的值出现
Rhat = mean(Rlist(covMask&secureMask));

% 最土的循环写法
% Rlist = [];
% for i = 1:numPulses
%     for j = 1:numPulses
%         if i ~= j
%             Rij = covMat(i,j) / (muMat(i)*muMat(j));
%             if ~isnan(Rij)
%                 Rlist(end+1) = Rij;
%             end
%         end
%     end
% end
% Rhat = mean(Rlist);             % σ_q² / q²

% 计算 E(q_trial²) = q² (1 + R-hat)
% q暂时没法求出来，但是我们可以先把其中重要的(1 + R-hat)算出来。
% 其实没什么特别必要的，这一块可以省略。
% E_q2_over_q2 = (1 + Rhat);

%--------------- 4. 计算 q 用(i,j,k,l)组合
% q = (μk²Fij-μi²Fkl) / (μkμi(1+R-hat)(μk-μi));
% 算法简化，因为(i,j,k,l)限制条件太复杂(i≠j,i≠k,k≠l)
% 先把所有的全组合捞出来，删除不符合条件的。
listIDVec = 1:numPulses;
% fullCombination = nchoosek(listIDVec,2); % C(T,2)
comb = table2array(combinations(listIDVec,listIDVec,listIDVec,listIDVec));
deleteMask = false(size(comb,1),3); % 三个限制条件
deleteMask(:,1) = comb(:,1)==comb(:,2);
deleteMask(:,2) = comb(:,1)==comb(:,3);
deleteMask(:,3) = comb(:,3)==comb(:,4);
deleteLine = any(deleteMask,2);
comb(deleteLine,:) = [];

muI = muMat(comb(:,1));
muK = muMat(comb(:,3));
ijSubID = sub2ind(size(F), comb(:,1), comb(:,2));
klSubID = sub2ind(size(F), comb(:,3), comb(:,4));
Fij = F(ijSubID);
Fkl = F(klSubID);

numerator   = (muK.^2) .* Fij - (muI.^2) .* Fkl;
denominator = muK .* muI * (1 + Rhat) .* (muK- muI);
q_list = numerator ./ denominator;
[q_list, ~] = rmoutliers(q_list, 'mean', 'ThresholdFactor', 3);
q = mean(q_list);
% q = median(q_list);
% q = mean(q_list(q_list>0));
% q = abs(median(q_list));

% 最土的循环计算方法
% q_list = [];
% 
% for i = 1:numPulses
%     for j = 1:numPulses
%         if i == j, continue; end
% 
%         for k = 1:numPulses
%             if k == i || k == j, continue; end
% 
%             for l = 1:numPulses
%                 if l == k, continue; end
% 
%                 numerator = mu(k)*mu(i)*(E_q2_over_q2)*(mu(k) - mu(i));
%                 denom = mu(k)^2 * F(i,j) - mu(i)^2 * F(k,l);
% 
%                 if denom ~= 0
%                     q_tmp = numerator / denom;
%                     if q_tmp > 0 && isfinite(q_tmp)
%                         q_list(end+1) = q_tmp;
%                     end
%                 end
%             end
%         end
%     end
% end
% 
% q = median(q_list);    % robust central tendency

%--------------- 5. 计算N
fullCombination = nchoosek(listIDVec,2); % C(T,2)
muI = muMat(fullCombination(:,1));
ijSubID = sub2ind(size(F), fullCombination(:,1), fullCombination(:,2));
Fij = F(ijSubID);
N_list = (muI.^2) ./ (muI*q - Fij/(1 + Rhat));
% [N_list, ~] = rmoutliers(N_list, 'mean', 'ThresholdFactor', 3);
% N = max(N_list);
% N = mean(N_list);
N = median(N_list);
% N_list = sort(N_list);
% N = N_list(round(length(N_list)*0.5));


% 最土的循环计算方法
% N_list = zeros(numPulses,1);
% E_q2 = q^2 * (1 + Rhat);
% 
% for i = 1:numPulses
%     for j = 1:numPulses
%         if i == j, continue; end
% 
%         N_list(i) = (mu(i)^2) / (mu(i)*q - F(i,j)/E_q2);
%     end
% end
% N = median(N_list);

%--------------- 6. 计算概率 p_i
p = muMat ./ (q * N);

%--------------- 7. 计算模型残差
recon = p .* N * q;    
rmse = sqrt(mean((recon - muMat').^2));

%--------------- 9. 结果输出
results.q = q;
results.N = N;
results.p = p;

results.rmse = rmse;

results.info.mu = muMat;
results.info.CovA = covMat;
results.info.F = F;
results.info.Rhat = Rhat;

end
