function colorRGB = GetColor(paramName)
% 用于获取本文配色
% q淡蓝色
% N橙黄色
% p紫色
switch lower(paramName)
    case 'q'
        colorRGB = [0.55 0.75 0.95];
    case 'n'
        colorRGB = [0.95 0.65 0.25];
    case 'p'
        colorRGB = [0.5, 0, 0.5];
end

end