function SimuEPSCUtils(epsc,q,N,U,tau_rec,tau_facil,stim_freq,num_stim,noise_std)
%---------------仿真参数（如需可在外部传入，这里保留接口）
% q = 3.07;                   % quantal size (pA)
% N = 650;                    % number of release sites∈[0.012–0.086]
% U = 0.0294;                 % baseline utilization (U 参数)
% tau_rec = 178;              % recovery time constant (ms)∈[104,694]
% tau_facil = 7984;           % facilitation time constant (ms)∈[550,3044]
%
% stim_freq = 75;             % stimulation frequency (Hz)
% num_stim = 10;              % number of stimuli
% ISI = 1000/stim_freq;       % inter-stimulus interval (ms)
%
% noise_std = 3.87;           % measurement noise (pA)

%---------------并行仿真
sweepN = 200;
epsc_data_Mat = zeros(sweepN,num_stim);
pi_Mat       = zeros(sweepN,num_stim);
N            = round(N);
tau_rec      = tau_rec * 1000;
tau_facil    = tau_facil * 1000;

for ii = 1:sweepN
    [epsc_data,pi] = GenerateSimuEPSC(q,round(N),U,stim_freq,tau_rec,tau_facil,num_stim,noise_std);
    epsc_data_Mat(ii,:) = epsc_data;
    pi_Mat(ii,:)        = pi;
end

%---------------绘图（同一个 figure，左右两个 axes）---------------
fHandle = figure;
fHandle.Position(3:4) = [1000,400];
tiledlayout(1,2);   % 1 行 2 列

% ---- 左图：EPSC ----
ax1 = nexttile;
plot(epsc_data_Mat','LineWidth',0.7);
xlabel('Stim index');          % 若你使用 ISI，可以改成 Time (ms)
ylabel('EPSC (pA)');
title('Simulated EPSC (Moment Info & MT Model)');
grid on;
ax1.XLim = [1,10];
% ---- 右图：释放概率 pi ----
ax2 = nexttile;
plot(epsc','LineWidth',0.7);
xlabel('Stim index');
ylabel('EPSC (pA)');
title('Real EPSC (Real Data)');
grid on;
ax2.XLim = [1,10];
% ---- 统一坐标范围（x 和 y 都设置成相同的限制）----
axs = [ax1, ax2];

% 先根据各自的范围求一个“并集”范围
xlim_all = [ ...
    min(cellfun(@(v)v(1), get(axs,'XLim'))), ...
    max(cellfun(@(v)v(2), get(axs,'XLim'))) ...
];
ylim_all = [ ...
    min(cellfun(@(v)v(1), get(axs,'YLim'))), ...
    max(cellfun(@(v)v(2), get(axs,'YLim'))) ...
];

set(axs, 'XLim', xlim_all, 'YLim', ylim_all);

%---------------输出统计信息---------------
fprintf('Mean EPSC = %.2f pA\n', mean(epsc_data_Mat,'all'));

end


% function SimuEPSCUtils(epsc,q,N,U,tau_rec,tau_facil,stim_freq,num_stim,noise_std)
% %---------------仿真参数
% % %----- 模型参数
% % q = 3.07;                   % quantal size (pA)
% % N = 650;                    % number of release sites∈[0.012–0.086]
% % U = 0.0294;                 % baseline utilization (U 参数)
% % tau_rec = 178;              % recovery time constant (ms)∈[104,694]
% % tau_facil = 7984;           % facilitation time constant (ms)∈[550,3044]
% % 
% % %----- 刺激参数
% % stim_freq = 75;             % stimulation frequency (Hz)
% % num_stim = 10;              % number of stimuli
% % ISI = 1000/stim_freq;       %
% %----- 噪声
% % noise_std = 3.87;     % measurement noise (pA)
% 
% %---------------并行仿真
% sweepN = 200;
% epsc_data_Mat = zeros(sweepN,num_stim);
% pi_Mat = zeros(sweepN,num_stim);
% N = round(N);
% tau_rec = tau_rec*1000;
% tau_facil = tau_facil*1000;
% for ii = 1:sweepN
%     [epsc_data,pi] = GenerateSimuEPSC(q,round(N),U,stim_freq,tau_rec,tau_facil,num_stim,noise_std);
%     epsc_data_Mat(ii,:) = epsc_data;
%     pi_Mat(ii,:) = pi;
% end
% 
% %----- 绘图 ----
% figure;
% % stem((1:num_stim) * ISI, mean(epsc_data_Mat,1), 'LineWidth', 1.5);
% % stem((1:num_stim) * ISI, mean(epsc_data_Mat(1,:),1), 'LineWidth', 1.5);
% plot(epsc_data_Mat');
% xlabel('Time (ms)');
% ylabel('EPSC (pA)');
% title('Simulated EPSC with R*u Release Probability (MT Model)');
% grid on;
% 
% %----- 输出统计信息 ----
% fprintf('Mean EPSC = %.2f pA\n', mean(epsc_data_Mat,'all'));
% % fprintf('STD  EPSC = %.2f pA\n', std(epsc_data));
% 
% figure();
% plot(epsc');
% end