function saveFigureTransparent(figHandle, fileName)
% saveFigureTransparent
% 保存指定 figure，背景设置为白色/透明，支持高分辨率导出
%
% 输入:
%   figHandle - figure 句柄，例如 gcf 或 figure(1)
%   fileName  - 保存的文件名，例如 'fig' 或 'result/fig'，会自动保存png和eps

% 设置 figure 为当前对象
figure(figHandle);

% figure 和 axes 背景设置
set(figHandle, 'Color', 'none');          % figure 背景透明
set(figHandle, 'Theme', 'light');         % figure 主题
set(findall(figHandle,'type','axes'), ...
    'Color', 'w');                        % 所有 subplot 背景白色

% 高分辨率导出
exportgraphics(figHandle, sprintf("%s.png",fileName), 'Resolution', 600);
fprintf('Figure saved as %s\n', fileName);

% 矢量图导出
% 构造 EPS 文件名
epsFileName = sprintf("%s.eps",fileName);

% 保存 SVG 矢量图
exportgraphics(figHandle, epsFileName, 'ContentType', 'vector');
saveas(figHandle, sprintf("%s.svg",fileName));
fprintf('SVG vector figure also saved as %s\n', epsFileName);

% 提示信息
fprintf('Figure saved as %s\n', fileName);

end
