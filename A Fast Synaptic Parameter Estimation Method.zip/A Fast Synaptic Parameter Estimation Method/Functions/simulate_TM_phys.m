function [modelVec,RList,uList] = simulate_TM_phys(x, nPulses, freqList)
% 在给定参数和频率列表下，模拟所有频率、所有脉冲的 EPSC
% x = [A, U, tau_rec, tau_facil]
% x = x_true;
% nPulses = params.num_stim;
% freqList = params.stim_freq;
A         = x(1);
U         = x(2);
tau_rec   = x(3);
tau_facil = x(4);

nFreq = numel(freqList);
modelMat = zeros(nPulses, nFreq);

RList = zeros(nPulses, nFreq);
uList = zeros(nPulses, nFreq);

for iFreq = 1:nFreq
    f  = freqList(iFreq);   % Hz
    dt = 1 / f;             % s，脉冲间隔

    % 初始条件：完全恢复，利用率为 U
    R = 1.0;
    u = U;

    for k = 1:nPulses
        % 当前脉冲 EPSC
        modelMat(k, iFreq) = A * R * u;

        % 从第 k 个脉冲后演化到下一个脉冲前
        % 易化变量 u 的衰减 + 跳增
        u_decay = u * exp(-dt / tau_facil);
        u_next  = u_decay + U * (1 - u_decay);

        % 资源 R：释放 u_next 后，再在 dt 内恢复
        R_depleted = R * (1 - u_next);
        R_next     = 1 - (1 - R_depleted) * exp(-dt / tau_rec);

        % 更新状态
        RList(k, iFreq) = R;
        uList(k, iFreq) = u;
        u = u_next;
        R = R_next;
    end
end

modelVec = modelMat(:);
end