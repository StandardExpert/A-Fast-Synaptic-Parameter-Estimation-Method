% DrawFigures
%------------------------------------------------------------------------
% 本函数用于绘制论文Fast calculation scheme based on second-order moments中
% 的相关图表。
% Liber T. Hua 2026/02//09
% 16:14 UTC+8:00

%% ------------------------------------------------------------------------
%                                 总体目标
%--------------------------------------------------------------------------
% Fig1. 整体突触活动模式示意图。

% Fig2. 算法示意图。展示方差协方差的定义。

% Fig3a. 绘制一个真的cell的EPSC Train的阴影分布情况。
% Fig3b. 绘制多个真的cell的EPSC均值曲线
% Fig3c. 绘制EPSC多个stimulus ID之间的协方差矩阵
% Fig3d. 分析stim ID之间的可靠性，相关系数图


% Fig4a，一个假Cell的q分布情况。
% Fig4b. 一群真Cell的q分布情况。
% Fig4c. 一群假Cell对N的估计
% Fig4d. 一群假Cell对pi的估计

% Fig5a，改变ση^2对q和N估计的影响。要绘制出预测的分布情况
% Fig5b. 改变ση^2对N估计的影响，带有T-M校准。要绘制出预测的分布情况
% Fig5c. 改变 q 的 trial-to-trial 变异(σq) 对 q 估计误差的影响
% Fig5d. 改变 q 的 trial-to-trial 变异(σq) 对 N 估计误差的影响
% Fig5e. 改变sweep数量T对q估计的影响
% Fig5f. 改变sweep数量T对N估计的影响
% Fig5g. 改变sweep数量T对p_i估计的影响
%% ------------------------------------------------------------------------
%                               基本参数设置
%--------------------------------------------------------------------------
%---------------数据处理
%----------超参
numFreq = 3; % 指有3种刺激频率
numPulses = 10;
numReps = 20;
plotColorList = [
    1,1,1;
    1,1,1;
    1,1,1;
    1,1,1;
    1,1,1];
stimFreq = ["20Hz","50Hz","75Hz"]; % 和上边的3种对应
abfpath = 'E:\TestCodes\short-term synaptic plasticity\EPSC raw';
EPSCpath = 'E:\TestCodes\short-term synaptic plasticity\VM outputs';
saveFolderName = "SaveData";
%-----------电信号相关参数
stimThreshold = 10; %大于这个数字表示刺激开始了。
%只有这以上的数据需要修改。


%% ------------------------------------------------------------------------
% Fig2. 算法示意图。展示方差协方差的定义。
%--------------------------------------------------------------------------
%----------文件路径整理
[filepath,name,ext] = fileparts(EPSCpath);
savePath = fullfile(filepath,saveFolderName);
if ~exist(savePath,"dir")
    mkdir(savePath)
end
%---------------配对文件表
% ccc

%我TM直接读取全部文件！
allAbfFile = dir(fullfile(abfpath, '**/*.abf'));
allEPSCFile = dir(fullfile(EPSCpath, '**/*.mat'));
allFileN = length(allEPSCFile);
%----------原始文件读取
% 获取每个Cell测试条件下的参数。
% 获取每个Cell、对应条件的原始文件和EPSC

variableNames = ["CellType","StimCondition","EPSCfile","abfFile"];
variableTypes = ["string","string","string","string"];
dataTable = table('Size' ,[allFileN,length(variableNames)], ...
    'VariableNames',variableNames, ...
    'VariableTypes',variableTypes);%cell类别（4个字符串），刺激条件（3种频率），abf文件路径，EPSC文件路径
%-----形成配对文件数据表
for fileID = 1:allFileN
    % 这里为了兼容以后可能的分割分类，就先把这个所有的字符分割了。
    % 最终的EPSC文件可能少于abf文件，所以以EPSC为主。
    resultStr = split(allEPSCFile(fileID).name, ["_","."]);
    resultStr(end) = [];
    % 目前为了数据处理简单，直接把Hz前面的文件名一串作为细胞的类别了。
    % 找到Hz是第几个
    [memberMask, indexInCondition] = ismember(lower(resultStr), lower(stimFreq));
    dataTable.CellType(fileID) = string(join(resultStr(~memberMask),"_"));
    dataTable.StimCondition(fileID) = string(resultStr(memberMask));
    dataTable.EPSCfile(fileID) = fullfile(allEPSCFile(fileID).folder, allEPSCFile(fileID).name);
    %找到对应的abf文件
    tempAbf = strrep(dataTable.EPSCfile(fileID),EPSCpath,abfpath);
    dataTable.abfFile(fileID) = strrep(tempAbf,'.mat','.abf');
end
%-----简单细胞类别unique
cellType = unique(dataTable.CellType, 'stable');
% ia是合并类的每一类起点索引
% ic是每条数据符合哪一类，即类编号。
cellTypeN = length(cellType);

%------------------------------------------------------------------------
%                              降采样绘图
%--------------------------------------------------------------------------
tempCellID = 1;
sampleBaseN = 100;
afterStimN = 100;
min_peak_height = 40;
min_peak_distance = 999;
stimVar = [2,7];
% stimVar = 1:10;
drawRepeatN = 20;
% 选择要绘制的行：前3行和最后2行
linesToPlot = [1:3, drawRepeatN-1:drawRepeatN];
numLinesToPlot = length(linesToPlot);
% Var示例点颜色
colorVar = {'r','b'};
%-----------降采样参数
downsampleFactor = 10; % 降采样因子，可根据需要调整



% 创建Y轴坐标映射，在前3行和最后2行之间添加间隔
yPositions = zeros(1, numLinesToPlot);
for i = 1:3
    yPositions(i) = i; % 前3行连续排列
end
% 在最后2行之前添加间隔
gapSize = 2; % 间隔大小
for i = 4:numLinesToPlot
    yPositions(i) = 3 + gapSize + (i-3); % 最后2行在间隔后排列
end

% Var plot
peakMarkerSize = 20;
% text
stimij = 'ij';
zOffset = -40;
% 配色
hue_range = linspace(0.6, 0.4, numLinesToPlot); % 色相
saturation_range = 0.4; % 饱和度固定
value_range = 0.9; % 明度

% 滤波
d = designfilt("lowpassiir",FilterOrder=12, ...
    HalfPowerFrequency=0.15,DesignMethod="butter");
[B,A] = ellip(3,0.1,40,[0.3 0.7],"ctf");
coreLen = 30;
coreFuc = ones(1, coreLen) / coreLen;

tempABFFile = dataTable.abfFile(tempCellID);
data0 = abfload(tempABFFile);
EPSCline = transpose(squeeze(data0(5000:18500,1,:)));
EPSCline = EPSCline(randperm(size(EPSCline,1)), :);%随机排列
stimLine = transpose(squeeze(data0(5000:18500,2,:)));

%---------------消除刺激伪迹
runsMat = (stimLine>=stimThreshold);
diffMat = diff(runsMat,1,2);
[endPointR, endPointC] = find(diffMat == 1);
[uniqueLine,ia,ic] = unique(endPointR);
peaksValue = zeros(length(uniqueLine),numPulses);
peaksLoc = zeros(length(uniqueLine),numPulses,2);

for lineID = 1:size(EPSCline,1)
    validC = endPointC(endPointR == lineID);
    for colID = 1:length(validC)
        tempC = validC(colID);
        validData = EPSCline(lineID, tempC-sampleBaseN : tempC);
        meanBase = repmat(mean(validData,2),1,afterStimN);
        EPSCline(lineID, tempC : tempC+afterStimN-1) = meanBase;
        if colID<length(validC)
            cutBin = EPSCline(lineID,tempC:validC(colID+1));
        else
            cutBin = EPSCline(lineID,tempC:end);
        end
        [peaks,pLoc] = findpeaks(-cutBin, ...
            'NPeaks',1, ...
            'MinPeakHeight', min_peak_height, ...
            'MinPeakDistance', min_peak_distance ...
            );
        peaksValue(lineID,colID) = -peaks;
        peaksLoc(lineID,colID,1) = lineID;
        peaksLoc(lineID,colID,2) = pLoc+tempC;
    end
    EPSCline(lineID,:) = conv(EPSCline(lineID,:),coreFuc,'same');

end

%---------------绘图
%----------绘制plot3 EPSC（带间隔的简化版）
fHandle = figure();
fHandle.Position(3:4) = [562,140];
ax = axes('Parent',fHandle);
hold(ax,'on');
xx = 1:size(EPSCline,2);

% 创建降采样索引
originalLength = size(EPSCline,2);
newLength = ceil(originalLength/downsampleFactor);
downsampleIndices = 1:downsampleFactor:originalLength;
if downsampleIndices(end) ~= originalLength
    downsampleIndices(end+1) = originalLength;
end
xx_downsampled = downsampleIndices;

% 绘制选定的行（降采样版本）
for plotIdx = 1:numLinesToPlot
    sweepID = linesToPlot(plotIdx);
    yy = zeros(1,length(xx_downsampled)) + yPositions(plotIdx);
    hue = hue_range(plotIdx);
    saturation = saturation_range;
    value = value_range;
    rgb_color = hsv2rgb([hue, saturation, value]);
    
    % 对数据进行降采样
    downsampledData = EPSCline(sweepID, downsampleIndices);
    
    plot3(ax, xx_downsampled, yy, downsampledData, ...
        'Color', rgb_color);
end

% 添加省略号表示中间省略的数据
if drawRepeatN > 5
    midY = (yPositions(3) + yPositions(4)) / 2;
    text(mean(xx), midY, min(EPSCline(:))/2, '....', ...
        'FontSize', 20, 'HorizontalAlignment', 'center', ...
        'Rotation',48, ...
        'Color', [0,0,0]);
end

ax.ZDir = "reverse";
ax.View = [7.2,75.7];
grid(ax,"on");

% 设置X轴标签
% ax.XTick = [];
% ax.XLabel.String = 'Time';

% ===== 设置X轴为 stimulus index =====
% 使用第一条 sweep 的峰值位置作为刻度位置
stimTickPos = squeeze(peaksLoc(linesToPlot(1),1:numPulses,2));

% 对齐到降采样后的X坐标
stimTickPos_ds = zeros(1,numPulses);
for i = 1:numPulses
    [~, idx] = min(abs(xx_downsampled - stimTickPos(i)));
    stimTickPos_ds(i) = xx_downsampled(idx);
end

ax.XTick = stimTickPos_ds;
ax.XTickLabel = 1:numPulses;
ax.XLabel.String = 'stimulus index';
% ax.XLabel.Position = [8349.64193759459,-1.418582778565323,18.91208127163827];
% ax.XLabel.Position = [7386.312182190395,-0.149238278514375,9.087395670941987];

% 设置Y轴标签
yTickPositions = [yPositions(1:3), midY, yPositions(4:end)];
yTickLabels = {'Sweep 1', 'Sweep 2', 'Sweep 3', '...', ...
    sprintf('Sweep %d', drawRepeatN-1), sprintf('Sweep %d', drawRepeatN)};
set(ax, 'YTick', yTickPositions, 'YTickLabel', yTickLabels);
% ylabel(ax, 'Sweep Number');
% 设置Z轴标签
ax.ZTick = [];
ax.ZLabel.String = 'EPSC(pA)';

%----------绘制Var与Cov（仅针对绘制的行）
% 在绘制Var与Cov部分，修改峰值标记的X坐标计算
varXYZ = zeros(length(stimVar),3);
for varStimID = 1:length(stimVar)
    tempStim = stimVar(varStimID);
    for plotIdx = 1:numLinesToPlot
        sweepID = linesToPlot(plotIdx);
        posXY = squeeze(peaksLoc(sweepID,tempStim,:));
        
        % 找到降采样后最接近的X坐标
        [~, closestIndex] = min(abs(xx_downsampled - posXY(2)));
        adjustedX = xx_downsampled(closestIndex);

        plot3(ax, adjustedX, yPositions(plotIdx), peaksValue(sweepID,tempStim), ...
            'Marker', '.', 'MarkerSize', peakMarkerSize, ...
            'Color', colorVar{varStimID});
    end
    % 文本标注使用最后一条数据的位置
    lastPlotIdx = numLinesToPlot;
    lastSweepID = linesToPlot(lastPlotIdx);
    posXY = squeeze(peaksLoc(lastSweepID,tempStim,:));
    varXYZ(varStimID,:) = [posXY(2), yPositions(lastPlotIdx), peaksValue(lastSweepID,tempStim)+zOffset];

    varTextHandle = text(varXYZ(varStimID,1),varXYZ(varStimID,2),varXYZ(varStimID,3), ...
        sprintf('$\\\\Var_{%s}$',stimij(varStimID)), ...
        'FontSize', 14, 'FontWeight', 'bold', 'Color', colorVar{varStimID}, ...
        'HorizontalAlignment', 'left', ...
        'Interpreter', 'latex');
end

covXYZ = mean(varXYZ,1);
covTextHandle = text(covXYZ(1),(yPositions(1)+yPositions(end))/2,covXYZ(3)-zOffset, ...
    sprintf('$\\\\Cov_{%s}$',stimij), ...
    'FontSize', 14, 'FontWeight', 'bold', 'Color', [132,58,145]./255, ...
    'HorizontalAlignment', 'center', ...
    'Interpreter', 'latex');

%-----Title
ax.Title.String = 'Data Structure';
ax.Color = 'none';
fHandle.Color = 'none';
% fHandle.InvertHardcopy = 'off';
hold(ax,'off');
print(fHandle, sprintf('%s.svg',ax.Title.String), '-dsvg','-r300', '-vector');

clc;
close all;
clear;

%% ------------------------------------------------------------------------
% Fig3a，绘制一个真的cell的EPSC Train的阴影分布情况。

%---------------给定参数生成仿真数据
params = GetDemoCellParams();
res = SimulateEPSCPeaks(params);
%-----对假数据绘图检查。
data = res.epsc_peaks;
[m, n] = size(data);
% x 轴（采样点）
x = 1:n;
% 计算均值和标准差（沿第 1 维，即 m 次重复）
meanData = mean(data, 1);
stdData  = std(data, 0, 1);
% 上下标准差
upperBound = meanData + stdData;
lowerBound = meanData - stdData;
% 绘图
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;
% 画标准差阴影
fill([x, fliplr(x)], ...
     [upperBound, fliplr(lowerBound)], ...
     [0.7 0.7 0.7], ...        % 阴影颜色（灰色）
     'EdgeColor', 'none', ...
     'FaceAlpha', 0.4);       % 透明度
% 画均值曲线（黑色实线）
plot(x, meanData, 'k-', 'LineWidth', 2);
% 图形美化
box on;
grid on;
xlabel('Stimulus Number');
ylabel('EPSC(pA)');
title('Example EPSC train (single cell)');

hold off;

saveFigureTransparent(figureHandle, 'fig3a');
close all;

%% ------------------------------------------------------------------------
% Fig3b，绘制一群真的cell的EPSC Train Mean的散布plot。
% 均值曲线（灰色）+ 总均值（黑色）

% 参数设置
Ncells = 30;   % cell数量（你可以修改）
params = GetDemoCellParams();
% 用于存储每个cell的均值曲线
cellMeans = NaN(Ncells,params.num_stim);

% 循环生成/导入每个cell的数据并绘图
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;
for ii = 1:Ncells
    
    %----------仿真数据占位
    % 这里先用仿真数据占位（你之后替换成真实cell数据）
    res = SimulateEPSCPeaks(params);
    data = res.epsc_peaks;   % [sweep × nSamplePoint]

    % 计算该cell的均值曲线（沿trial维度求平均）
    meanData = mean(data, 1);   % 1 × n

    % 保存下来用于后续 grand mean
    cellMeans(ii, :) = meanData;

    % x轴
    x = 1:length(meanData);

    % 绘制每个cell的均值曲线（灰色细线）
    plot(x, meanData, 'Color', [0.7 0.7 0.7], 'LineWidth', 1);
end

% 计算所有cell的总均值（grand mean）
grandMean = mean(cellMeans, 1);

% 绘制总均值曲线（黑色粗线）
plot(x, grandMean, 'k-', 'LineWidth', 2.5);

% 图形美化
box on;
grid on;
xlabel('Stimulus Number');
ylabel('EPSC (pA)');
title('EPSC Mean Across Cells');

hold off;

% 保存透明背景图
saveFigureTransparent(figureHandle, 'fig3b');
close all;

%% ------------------------------------------------------------------------
% Fig3c，绘制EPSC多个stimulus ID之间的协方差矩阵
%---------------仿真数据
params = GetDemoCellParams();
res = SimulateEPSCPeaks(params);
data = res.epsc_peaks;   % [sweep × nSamplePoint]
%-----计算 stim × stim 协方差矩阵
covMatrix = cov(data);   % 每个 stim 作为一个变量

%---------------绘图
figureHandle = figure('Position',[100, 100, 560, 420]);

imagesc(covMatrix);
axis square;
box on;

% 使用更适合神经数据的colormap
colormap(parula);
colorbar;

xlabel('Stimulus Number i');
ylabel('Stimulus Number j');
title('Covariance Matrix Between EPSC i & j');

% 可选：让颜色对称（更直观）
% cmax = max(abs(covMatrix(:)));
% caxis([-cmax cmax]);

saveFigureTransparent(figureHandle, 'fig3c');
close all;


%% ------------------------------------------------------------------------
% Fig3d，分析stim ID之间的可靠性，相关系数图
% 带有 sweep-dependent q variability 的 scatter plot
% 模拟 q 在不同 sweep 间轻微波动（9~11）

%---------------仿真数据（基础）
params = GetDemoCellParams();
res = SimulateEPSCPeaks(params);
data = res.epsc_peaks;   % [sweep × nStimulus]

[nSweep, nStim] = size(data);

%---------------引入 sweep-level q 变异
% 原本 q = 10
% 现在让 q 在 9~11 之间轻微波动

gain = 1 + 0.2*randn(nSweep,1);

% 乘到每个 sweep 上
data_var = data .* gain;

%---------------随机选两个 stimulus
stimPair = randperm(nStim, 2);
stim_i = stimPair(1);
stim_j = stimPair(2);

x = data_var(:, stim_i);
y = data_var(:, stim_j);

%---------------计算相关系数
R = corrcoef(x, y);
r = R(1,2);

%---------------线性拟合
p = polyfit(x, y, 1);
xLine = linspace(min(x), max(x), 200);
yLine = polyval(p, xLine);

%---------------绘图
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

scatter(x, y, 40, 'filled', ...
    'MarkerFaceAlpha', 0.6);

plot(xLine, yLine, 'k-', 'LineWidth', 2);

box on;
axis square;

xlabel(['Stimulus ' num2str(stim_i) ' EPSC Amplitude']);
ylabel(['Stimulus ' num2str(stim_j) ' EPSC Amplitude']);

title('Sweep-dependent Multiplicative Variability');

text(0.05, 0.90, ...
    ['r = ' num2str(r, '%.2f')], ...
    'Units', 'normalized', ...
    'FontSize', 12, ...
    'FontWeight', 'bold');

saveFigureTransparent(figureHandle, 'fig3d');
close all;




%% ------------------------------------------------------------------------
% Fig4a，一群假Cell的q分布情况。

%---------------给定参数生成仿真数据
params = GetDemoCellParams();
params.num_sweeps = 100;
mcSamplingN = 50;
qList = NaN(1,mcSamplingN);
% NList = NaN(1,mcSamplingN);
% piList = NaN(params.num_stim,mcSamplingN);
parfor ii = 1:mcSamplingN
    res = SimulateEPSCPeaks(params);
    result = estimate_synapse_params(res.epsc_peaks', params.noise_std);
    qList(ii) = result.q;
end
[q_List, ~] = rmoutliers(qList, 'mean', 'ThresholdFactor', 3);
% scatter(1:length(q_List),q_List);
% histogram(q_List)
% mean(q_List)
% std(q_List)

%----------绘制参数计算分布图
q = q_List(:);
q = q(~isnan(q));

% --- 自动从 params 里找“真值 q”
n_true = NaN;
if exist('params','var')
    if isfield(params,'q_true'), n_true = params.q_true; end
    if isnan(n_true) && isfield(params,'q0'), n_true = params.q0; end
    if isnan(n_true) && isfield(params,'q'),  n_true = params.q;  end
end

mu = mean(q);
sd = std(q);
n  = numel(q);

% --- 自动选择 bins（稳健一些）
numBins = max(10, round(sqrt(n)));  % 也可用: round(1 + log2(n))

figureHandle = figure('Position',[100, 100, 560, 420]);
tiledlayout(1,1,'Padding','compact','TileSpacing','compact');
ax = nexttile; hold(ax,'on'); box(ax,'on');

% 直方图（归一化成 pdf，方便叠加 KDE）
h = histogram(ax, q, numBins, 'Normalization','pdf', ...
    'EdgeColor','none', ...
    'FaceColor',GetColor('q'), ...
    'FaceAlpha',0.35);

% KDE（平滑密度曲线）
% ksdensity 在统计工具箱里；如果没有工具箱，用第 2 节备选方案
[f,xi] = ksdensity(q);
p = plot(ax, xi, f, 'LineWidth',2.2);

% 均值线
xline(ax, mu, '--', sprintf('\\mu=%.3g',mu), ...
    'LineWidth',1.8, 'LabelOrientation','horizontal', ...
    'LabelVerticalAlignment','middle');

% 真值线（如果找得到）
if ~isnan(n_true)
    xline(ax, n_true, '-', sprintf('q_{true}=%.3g',n_true), ...
        'LineWidth',2.4, 'LabelOrientation','horizontal', ...
        'LabelVerticalAlignment','bottom');
end

% 图形细节：标题/标注/字体
title(ax, 'Distribution of Estimated q across Monte Carlo Cells');
xlabel(ax, 'q');
ylabel(ax, 'Probability Density');

% 角落文本：n、std
txt = sprintf('n=%d, \\sigma=%.3g', n, sd);
text(ax, 0.98, 0.95, txt, 'Units','normalized', ...
    'HorizontalAlignment','right', 'VerticalAlignment','top', ...
    'FontSize',11);

% 美化
set(ax, 'FontName','Arial', 'FontSize',12, 'LineWidth',1.1);
grid(ax,'on'); ax.GridAlpha = 0.15;

% 图例（可选）
legend(ax, [h p], {'Histogram (pdf)','KDE'}, 'Location','best');
hold(ax,'off');

% 导出：矢量 + 600dpi PNG
saveFigureTransparent(figureHandle, 'fig4a');
close all;



%% ------------------------------------------------------------------------
% Fig4b. 一群真Cell的q分布情况。

% ====== 1) 指向 mainScripts 最后保存的 totalSaveData.mat ======
% 这个文件是 mainScripts 统计阶段保存的：save(saveDataFile,'readme','data',...)
EPSCpath = 'E:\TestCodes\short-term synaptic plasticity\VM outputs';
saveFolderName = "SaveData";
%----------文件路径整理
[filepath,name,ext] = fileparts(EPSCpath);
saveDataFile = fullfile(filepath, "totalSaveData.mat");
S = load(saveDataFile, "data");
data = S.data;

% ====== 2) 选择"同种类真实神经元" ======
targetClass = "C";  % 例如 Ctrl='C'（你们项目里常见是 'C','L','Y','K' 等）
q_raw = data.q(data.CellClass == targetClass);

q_raw = q_raw(:);
q_raw = q_raw(isfinite(q_raw) & ~isnan(q_raw));

% ====== 3) 去异常（MC Fig4a 风格一致） ======
[q, TF] = rmoutliers(q_raw, 'mean', 'ThresholdFactor', 3);
q = q(:);

mu = mean(q);
sd = std(q);
n  = numel(q);

% ====== 4) 画"漂亮分布图"：Histogram(pdf) + KDE + 均值线 + 目标线(可选) ======
q_target = NaN;  % 如果有"目标/参考 q"（比如你们仿真的真值），填这里；没有就保持 NaN

numBins = max(10, round(sqrt(n)));

figureHandle = figure('Position',[100, 100, 560, 420]);
tiledlayout(1,1,'Padding','compact','TileSpacing','compact');
ax = nexttile; hold(ax,'on'); box(ax,'on');

h = histogram(ax, q, numBins, 'Normalization','pdf', ...
    'EdgeColor','none', ...
    'FaceColor',GetColor('q'), ...
    'FaceAlpha',0.35);

% KDE（需要统计工具箱）
[f,xi] = ksdensity(q);
p = plot(ax, xi, f, 'LineWidth',2.2);

xline(ax, mu, '--', sprintf('\\mu=%.3g',mu), ...
    'LineWidth',1.8, 'LabelOrientation','horizontal', ...
    'LabelVerticalAlignment','middle');

if ~isnan(q_target)
    xline(ax, q_target, '-', sprintf('q_{target}=%.3g',q_target), ...
        'LineWidth',2.4, 'LabelOrientation','horizontal', ...
        'LabelVerticalAlignment','bottom');
end

title(ax, sprintf('Real Cells (%s): Distribution of Estimated q', targetClass));
xlabel(ax, 'q');
ylabel(ax, 'Probability Density');

txt = sprintf('n=%d, \\sigma=%.3g (outliers removed=%d)', n, sd, sum(TF));
text(ax, 0.98, 0.95, txt, 'Units','normalized', ...
    'HorizontalAlignment','right', 'VerticalAlignment','top', ...
    'FontSize',11);

set(ax, 'FontName','Arial', 'FontSize',12, 'LineWidth',1.1);
grid(ax,'on'); ax.GridAlpha = 0.15;
pause(1);
legend(ax, [h p], {'Histogram (pdf)','KDE'}, 'Location','best');

saveFigureTransparent(figureHandle, 'fig4b');
close all;


%% ------------------------------------------------------------------------
% Fig4c. 一群假Cell对N的估计
%---------------给定参数生成仿真数据
params = GetDemoCellParams();
params.num_sweeps = 1000;
mcSamplingN = 50;
% qList = NaN(1,mcSamplingN);
NList = NaN(1,mcSamplingN);
parfor ii = 1:mcSamplingN
    res = SimulateEPSCPeaks(params);
    result = estimate_synapse_params(res.epsc_peaks', params.noise_std);
    % qList(ii) = result.q;
    NList(ii) = result.N;
end

% histogram(NList)
% [N_List, ~] = rmoutliers(NList, 'mean', 'ThresholdFactor', 3);
N_List = NList;
% scatter(1:length(N_List),N_List);
% mean(N_List(N_List>0))
% per = find(params.N<sort(N_List),1,'first')/length(N_List);
% histogram(N_List)
% mean(N_List)
% std(N_List)
%----------绘制参数计算分布图
N = N_List(:);
N = N(~isnan(N));

% --- 自动从 params 里找"真值 N"
N_true = NaN;
if exist('params','var')
    if isfield(params,'N_true'), N_true = params.N_true; end
    if isnan(N_true) && isfield(params,'N0'), N_true = params.N0; end
    if isnan(N_true) && isfield(params,'N'),  N_true = params.N;  end
end

mu = mean(N);
sd = std(N);
n  = numel(N);

% --- 自动选择 bins（稳健一些）
numBins = max(10, round(sqrt(n)));  % 也可用: round(1 + log2(n))

figureHandle = figure('Position',[100, 100, 560, 420]);
tiledlayout(1,1,'Padding','compact','TileSpacing','compact');
ax = nexttile; hold(ax,'on'); box(ax,'on');

% 直方图（归一化成 pdf，方便叠加 KDE）
h = histogram(ax, N, numBins, 'Normalization','pdf', ...
    'EdgeColor','none', ...
    'FaceColor',GetColor('N'), ...
    'FaceAlpha',0.35);

% KDE（平滑密度曲线）
% ksdensity 在统计工具箱里；如果没有工具箱，用第 2 节备选方案
[f,xi] = ksdensity(N);
p = plot(ax, xi, f, 'LineWidth',2.2);

% 均值线
xline(ax, mu, '--', sprintf('\\mu=%.3g',mu), ...
    'LineWidth',1.8, 'LabelOrientation','horizontal', ...
    'LabelVerticalAlignment','middle');

% 真值线（如果找得到）
if ~isnan(N_true)
    xline(ax, N_true, '-', sprintf('N_{true}=%.3g',N_true), ...
        'LineWidth',2.4, 'LabelOrientation','horizontal', ...
        'LabelVerticalAlignment','bottom');
end

% 图形细节：标题/标注/字体
title(ax, 'Distribution of Estimated N across Monte Carlo Cells');
xlabel(ax, 'N');
ylabel(ax, 'Probability Density');

% 角落文本：n、std
txt = sprintf('n=%d, \\sigma=%.3g', n, sd);
text(ax, 0.98, 0.95, txt, 'Units','normalized', ...
    'HorizontalAlignment','right', 'VerticalAlignment','top', ...
    'FontSize',11);

% 美化
set(ax, 'FontName','Arial', 'FontSize',12, 'LineWidth',1.1);
grid(ax,'on'); ax.GridAlpha = 0.15;

% 图例（可选）
legend(ax, [h p], {'Histogram (pdf)','KDE'}, 'Location','best');
hold(ax,'off');

% 导出：矢量 + 600dpi PNG
saveFigureTransparent(figureHandle, 'fig4c');
close all;


%% ------------------------------------------------------------------------
% Fig4d. 一群仿真Cell的释放概率 p_i 随 stimulus 变化
% 灰色虚线：每个 Monte Carlo cell
% 黑色实线：TM 模型真值

params = GetDemoCellParams();
params.num_sweeps = 1000;

mcSamplingN = 50;              % 仿真cell数量
pList = NaN(params.num_stim, mcSamplingN);

% ---------- Monte Carlo 生成仿真cell ----------
parfor ii = 1:mcSamplingN
    
    % 1) 生成EPSC数据
    res = SimulateEPSCPeaks(params);
    result = estimate_synapse_params(res.epsc_peaks', params.noise_std);
    pList(:,ii) = result.p;

    % 2) 拟合TM模型
    % fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);
    
    % 3) 根据 TM 的 A 得到 π_i
    % EPSC_mean = N * q * pi_i = A * pi_i
    % => pi_i = mean(EPSC)/A
    % pList(:,ii) = mean(res.epsc_peaks,1)' / fitResult.A;
    
    fprintf("Simulation Progress[%d%%]\n", round(100*ii/mcSamplingN));
end


% ---------- 计算 TM 真值 p_i ----------
% 使用原始参数直接模拟 TM 释放概率
x_true = [params.N * params.q, ...
          params.U, ...
          params.tau_rec/1000, ...
          params.tau_facil/1000];

[~, R_true, u_true] = ...
    simulate_TM_phys(x_true, params.num_stim, params.stim_freq);

p_true = u_true .* R_true;     % TM 真正释放概率


% =======================  绘图  ==============================
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

x = 1:params.num_stim;

% ----- 每个cell的π_i（灰色虚线）-----
for ii = 1:mcSamplingN
    plot(x, pList(:,ii), '--', ...
        'Color', [0.7 0.7 0.7], ...
        'LineWidth', 1);
end

% ----- TM 真值（紫色实线）-----
plot(x, p_true, 'Color', GetColor('p'), 'LineWidth', 2.5);

box on;
grid on;

xlabel('Stimulus Number');
ylabel('p_i (Release Probability)');
title('p_i Across Monte Carlo Cells');

hold off;

saveFigureTransparent(figureHandle, 'fig4d');
close all;

%% ------------------------------------------------------------------------
% Fig4e. 一群假Cell对N的估计，带有TM校准
%---------------给定参数生成仿真数据
params = GetDemoCellParams();
params.num_sweeps = 1000;
mcSamplingN = 50;
qList = NaN(1,mcSamplingN);
NList = NaN(1,mcSamplingN);
parfor ii = 1:mcSamplingN
    res = SimulateEPSCPeaks(params);
    result = estimate_synapse_params(res.epsc_peaks', params.noise_std);
    % 2) 拟合TM模型
    fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);
    
    % 3) 根据 TM 的 A 得到 N
    % EPSC_mean = N * q * pi_i = A * pi_i
    result.N = fitResult.A / result.q;
    qList(ii) = result.q;
    NList(ii) = result.N;
end

N_List = NList;

%----------绘制参数计算分布图
N = N_List(:);
N = N(~isnan(N));

% --- 自动从 params 里找"真值 N"
N_true = NaN;
if exist('params','var')
    if isfield(params,'N_true'), N_true = params.N_true; end
    if isnan(N_true) && isfield(params,'N0'), N_true = params.N0; end
    if isnan(N_true) && isfield(params,'N'),  N_true = params.N;  end
end

mu = mean(N);
sd = std(N);
n  = numel(N);

% --- 自动选择 bins（稳健一些）
numBins = max(10, round(sqrt(n)));  % 也可用: round(1 + log2(n))

figureHandle = figure('Position',[100, 100, 560, 420]);
tiledlayout(1,1,'Padding','compact','TileSpacing','compact');
ax = nexttile; hold(ax,'on'); box(ax,'on');

% 直方图（归一化成 pdf，方便叠加 KDE）
h = histogram(ax, N, numBins, 'Normalization','pdf', ...
    'EdgeColor','none', ...
    'FaceColor',GetColor('N'), ...
    'FaceAlpha',0.35);

% KDE（平滑密度曲线）
% ksdensity 在统计工具箱里；如果没有工具箱，用第 2 节备选方案
[f,xi] = ksdensity(N);
p = plot(ax, xi, f, 'LineWidth',2.2);

% 均值线
xline(ax, mu, '--', sprintf('\\mu=%.3g',mu), ...
    'LineWidth',1.8, 'LabelOrientation','horizontal', ...
    'LabelVerticalAlignment','middle');

% 真值线（如果找得到）
if ~isnan(N_true)
    xline(ax, N_true, '-', sprintf('N_{true}=%.3g',N_true), ...
        'LineWidth',2.4, 'LabelOrientation','horizontal', ...
        'LabelVerticalAlignment','bottom');
end

% 图形细节：标题/标注/字体
title(ax, 'Distribution of Estimated N with T-M Calibration');
xlabel(ax, 'N');
ylabel(ax, 'Probability Density');

% 角落文本：n、std
txt = sprintf('n=%d, \\sigma=%.3g', n, sd);
text(ax, 0.98, 0.95, txt, 'Units','normalized', ...
    'HorizontalAlignment','right', 'VerticalAlignment','top', ...
    'FontSize',11);

% 美化
set(ax, 'FontName','Arial', 'FontSize',12, 'LineWidth',1.1);
grid(ax,'on'); ax.GridAlpha = 0.15;

% 图例（可选）
pause(1.0);
legend(ax, [h p], {'Histogram (pdf)','KDE'}, 'Position',[0.65,0.72,0.26,0.1]);
hold(ax,'off');
pause(1.0);

% 导出：矢量 + 600dpi PNG
saveFigureTransparent(figureHandle, 'fig4e');
close all;

%% ------------------------------------------------------------------------
% Fig4f. 一群仿真Cell的释放概率 p_i 随 stimulus 变化，带TM矫正
% 灰色虚线：每个 Monte Carlo cell
% 黑色实线：TM 模型真值

params = GetDemoCellParams();
params.num_sweeps = 1000;

mcSamplingN = 50;              % 仿真cell数量
pList = NaN(params.num_stim, mcSamplingN);

% ---------- Monte Carlo 生成仿真cell ----------
parfor ii = 1:mcSamplingN
    
    % 1) 生成EPSC数据
    res = SimulateEPSCPeaks(params);
    result = estimate_synapse_params(res.epsc_peaks', params.noise_std);
    pList(:,ii) = result.p;

    % 2) 拟合TM模型
    fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);
    
    % 3) 根据 TM 的 A 得到 π_i
    % EPSC_mean = N * q * pi_i = A * pi_i
    % => pi_i = mean(EPSC)/A
    pList(:,ii) = mean(res.epsc_peaks,1)' / fitResult.A;
    fprintf("Simulation Progress[%d%%]\n", round(100*ii/mcSamplingN));
end


% ---------- 计算 TM 真值 π_i ----------
% 使用原始参数直接模拟 TM 释放概率
x_true = [params.N * params.q, ...
          params.U, ...
          params.tau_rec/1000, ...
          params.tau_facil/1000];

[modelVec_true, R_true, u_true] = ...
    simulate_TM_phys(x_true, params.num_stim, params.stim_freq);

p_true = u_true .* R_true;     % TM 真正释放概率


% =======================  绘图  ==============================
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

x = 1:params.num_stim;

% ----- 每个cell的π_i（灰色虚线）-----
for ii = 1:mcSamplingN
    plot(x, pList(:,ii), '--', ...
        'Color', [0.7 0.7 0.7], ...
        'LineWidth', 1);
end

% ----- TM 真值（紫色实线）-----
plot(x, p_true, 'Color', GetColor('p'), 'LineWidth', 2.5);

box on;
grid on;

xlabel('Stimulus Number');
ylabel('p_i (Release Probability)');
title('p_i with T-M Calibration');

hold off;

saveFigureTransparent(figureHandle, 'fig4f');
close all;


%% ------------------------------------------------------------------------
% Fig5a，改变ση^2对q和N估计的影响。要绘制出预测的分布情况
% 3D orthographic violin plot
% Nature-style, minimal, publication-ready

clear; clc;

%-------------------- 参数设置 --------------------
sigmaList = 0:5:50;                 % 噪声水平 (pA)
nSigma    = numel(sigmaList);
mcN       = 200;                    % 每个 sigma 的 Monte Carlo 次数

params0 = GetDemoCellParams();
params0.num_sweeps = 300;           % 稍微大一点，估计更稳

% 存储
q_all = cell(nSigma,1);
N_all = cell(nSigma,1);
%-------------------- Monte Carlo 仿真 --------------------
fprintf('Running Monte Carlo simulation...\n');

for si = 1:nSigma
    params = params0;
    params.noise_std = sigmaList(si);

    q_tmp = NaN(mcN,1);
    N_tmp = NaN(mcN,1);
    N_tmpCali = NaN(mcN,1);
    parfor k = 1:mcN
        % 1) 估算
        res = SimulateEPSCPeaks(params);
        est = estimate_synapse_params(res.epsc_peaks', params.noise_std);
        
        q_tmp(k) = est.q;
        N_tmp(k) = est.N;
    end

    % 去除 NaN / 极端异常
    q_tmp = q_tmp(isfinite(q_tmp));
    N_tmp = N_tmp(isfinite(N_tmp));

    q_all{si} = q_tmp;
    N_all{si} = N_tmp(N_tmp>0);

    fprintf('σ = %d pA finished (%d samples)\n', ...
        sigmaList(si), numel(q_tmp));
end

% -------------------- 绘图 --------------------
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

col_q = GetColor('q');      % 淡蓝色
alpha_violin = 0.45;
width = 2;

for si = 1:nSigma
    x0 = sigmaList(si);
    data = q_all{si}(:);

    if numel(data) < 10
        continue;
    end

    [f,xi] = ksdensity(data);
    f = f ./ max(f) * width;

    X = transpose([x0 + f, fliplr(x0 - f)]);
    Y = [xi'; flipud(xi')];

    fill(X,Y,col_q, ...
        'FaceAlpha',alpha_violin, ...
        'EdgeColor','none');

    % 中位数点
    plot(x0, mean(data), 'k.', 'MarkerSize',14);
end

% 中位数轨迹
q_med = cellfun(@mean, q_all);
plot(sigmaList, q_med, 'k-', 'LineWidth',2);

xlabel('\sigma (pA)');
ylabel('Estimated q');

set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
box on;
grid on;
ax = gca;
ax.GridAlpha = 0.15;

title('Noise-dependent estimation of q');

% 调整y轴显示范围
all_q_data = vertcat(q_all{:});          % 合并所有 q 数据
all_q_data = all_q_data(isfinite(all_q_data)); % 确保无 NaN
ylims = prctile(all_q_data, [0.5, 99.5]);
if ylims(1) == ylims(2)
    ylims = ylims + [-0.1, 0.1];
end
ylim(ylims);

%-------------------- 保存 --------------------
saveFigureTransparent(figureHandle, 'fig5a');
close all;

%% ------------------------------------------------------------------------
% Fig5b，改变ση^2对N估计的影响，带有TM校准。要绘制出预测的分布情况
% 3D orthographic violin plot
% Nature-style, minimal, publication-ready
%-------------------- 参数设置 --------------------
sigmaList = 0:5:35;                 % 噪声水平 (pA)
nSigma    = numel(sigmaList);
mcN       = 200;                    % 每个 sigma 的 Monte Carlo 次数

params0 = GetDemoCellParams();
params0.num_sweeps = 300;           % 稍微大一点，估计更稳

% 存储
q_all = cell(nSigma,1);
N_all = cell(nSigma,1);
N_allCali = cell(nSigma,1);
%-------------------- Monte Carlo 仿真 --------------------
fprintf('Running Monte Carlo simulation...\n');

for si = 1:nSigma
    params = params0;
    params.noise_std = sigmaList(si);

    q_tmp = NaN(mcN,1);
    N_tmp = NaN(mcN,1);
    N_tmpCali = NaN(mcN,1);
    parfor k = 1:mcN
        % 1) 估算
        res = SimulateEPSCPeaks(params);
        est = estimate_synapse_params(res.epsc_peaks', params.noise_std);
        % 2) 拟合TM模型
        fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);

        % 3) 根据 TM 的 A 得到 π_i
        % EPSC_mean = N * q * pi_i = A * pi_i
        % => pi_i = mean(EPSC)/A
        
        q_tmp(k) = est.q;
        N_tmp(k) = est.N;
        N_tmpCali(k) = fitResult.A / est.q;
    end

    % 去除 NaN / 极端异常
    q_tmp = q_tmp(isfinite(q_tmp));
    N_tmp = N_tmp(isfinite(N_tmp));

    q_all{si} = q_tmp;
    N_all{si} = N_tmp(N_tmp>0);
    N_allCali{si} = N_tmpCali(isfinite(N_tmpCali));

    fprintf('σ = %d pA finished (%d samples)\n', ...
        sigmaList(si), numel(q_tmp));
end

% -------------------- Figure 2 : N --------------------
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

col_N = GetColor('N');      % 橙黄色
alpha_violin = 0.45;
width = 2;

for si = 1:nSigma
    x0 = sigmaList(si);
    data = N_allCali{si}(:);

    if numel(data) < 10
        continue;
    end

    [f,xi] = ksdensity(data);
    f = f ./ max(f) * width;

    X = transpose([x0 + f, fliplr(x0 - f)]);
    Y = [xi'; flipud(xi')];

    fill(X,Y,col_N, ...
        'FaceAlpha',alpha_violin, ...
        'EdgeColor','none');

    % 均制点
    plot(x0, mean(data), 'k.', 'MarkerSize',14);
end

% 均值轨迹
N_mean = cellfun(@mean, N_allCali);
plot(sigmaList, N_mean, 'k-', 'LineWidth',2);

xlabel('\sigma (pA)');
ylabel('Estimated N');

set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
box on;
grid on;
ax = gca;
ax.GridAlpha = 0.15;

title('Noise-dependent estimation of N');

% 调整y轴显示范围
all_N_data = vertcat(N_allCali{:});
all_N_data = all_N_data(isfinite(all_N_data));
ylims = prctile(all_N_data, [0.5, 99]);
ylims(1) = -50;
if ylims(1) == ylims(2)
    ylims = ylims + [-0.1, 0.1];
end
ylim(ylims);

%-------------------- 保存 --------------------
saveFigureTransparent(figureHandle, 'fig5b');
close all;

%% ------------------------------------------------------------------------
% Fig5c 改变 q 的 trial-to-trial 变异(σq) 对 q 估计误差的影响
% 3D orthographic violin plot
% Nature-style, minimal, publication-ready

clear; clc;

%-------------------- 参数设置 --------------------
sigmaQList = 0:0.5:5;              % q 的随机变异标准差 (pA) ——你按需要改范围
nSigma     = numel(sigmaQList);
mcN        = 200;

params0 = GetDemoCellParams();
params0.num_sweeps = 300;

% 固定测量噪声（如果你们仍想保留 measurement noise）
% params0.noise_std = 10;          % 例如固定 10 pA；若 GetDemoCellParams 已给定也可不动

q0_true = params0.q;               % baseline “真实” q
% N0_true = params0.N;               % baseline “真实” N（本图只用来生成，但误差画 q）

% 存储：每个 σq 下的 q_error
qerr_all = cell(nSigma,1);

fprintf('Running Monte Carlo simulation (q variability)...\n');

for si = 1:nSigma
    params = params0;
    sigma_q = sigmaQList(si);

    qerr_tmp = NaN(mcN,1);

    parfor k = 1:mcN
        params_k = params;

        % 1) 为本次仿真生成“真实 q”（截断为正）
        q_true_k = q0_true + sigma_q * randn();
        if q_true_k <= 0
            q_true_k = eps; % 或者用 abs(q_true_k)
        end
        params_k.q = q_true_k;

        % 2) 仿真 + 估计
        res = SimulateEPSCPeaks(params_k);
        est = estimate_synapse_params(res.epsc_peaks', params_k.noise_std);

        % 3) 误差（默认 relative error；要 absolute 改下一行即可）
        % qerr_tmp(k) = (est.q - q_true_k) / q_true_k;
        qerr_tmp(k) = (est.q - q0_true);   % <-- absolute error
    end

    qerr_tmp = qerr_tmp(isfinite(qerr_tmp));
    qerr_all{si} = rmoutliers(qerr_tmp, 'mean', 'ThresholdFactor', 10);

    % scatter(qerr_all{si},1:length(qerr_all{si}))
    fprintf('σq = %.3g pA finished (%d samples)\n', sigma_q, numel(qerr_tmp));
end

% -------------------- 绘图 --------------------
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

col_q = GetColor('q');
alpha_violin = 0.45;
width = 0.2;

for si = 1:nSigma
    x0 = sigmaQList(si);
    data = qerr_all{si}(:);

    if numel(data) < 10
        continue;
    end

    [f,xi] = ksdensity(data);
    f = f ./ max(f) * width;

    X = transpose([x0 + f, fliplr(x0 - f)]);
    Y = [xi'; flipud(xi')];

    fill(X,Y,col_q, ...
        'FaceAlpha',alpha_violin, ...
        'EdgeColor','none');

    % 中心点（和你们原图一致：黑点画 mean）
    plot(x0, mean(data), 'k.', 'MarkerSize',14);
end

% 均值轨迹
qerr_mean = cellfun(@mean, qerr_all);
plot(sigmaQList, qerr_mean, 'k-', 'LineWidth',2);

xlabel('\sigma_q (pA)');
ylabel('q estimation error (pA)');   % 若是 relative error，可改成 'Relative error of q'
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
box on;
grid on;
ax = gca;
ax.GridAlpha = 0.15;

title('q-variability-dependent error of q estimation');

% y 轴范围（保持你们原来的 percentile 逻辑）
all_data = vertcat(qerr_all{:});
all_data = all_data(isfinite(all_data));
ylims = prctile(all_data, [0.5, 99.5]);
if ylims(1) == ylims(2)
    ylims = ylims + [-0.1, 0.1];
end
ylim(ylims);

saveFigureTransparent(figureHandle, 'fig5c');
close all;



%% ------------------------------------------------------------------------
% Fig5d 改变 q 的 trial-to-trial 变异(σq) 对 N 估计误差的影响
% 3D orthographic violin plot
% Nature-style, minimal, publication-ready

clear; clc;

%-------------------- 参数设置 --------------------
sigmaQList = 0:0.5:5;              % q 的随机变异标准差 (pA) ——你按需要改范围
nSigma     = numel(sigmaQList);
mcN        = 200;

params0 = GetDemoCellParams();
params0.num_sweeps = 300;

% 固定测量噪声（如果你们仍想保留 measurement noise）
% params0.noise_std = 10;          % 例如固定 10 pA；若 GetDemoCellParams 已给定也可不动

q0_true = params0.q;               % baseline “真实” q
N0_true = params0.N;               % baseline “真实” N（本图只用来生成，但误差画 q）

% 存储：每个 σq 下的 q_error
nerr_all = cell(nSigma,1);

fprintf('Running Monte Carlo simulation (q variability)...\n');

for si = 1:nSigma
    params = params0;
    sigma_q = sigmaQList(si);

    nerr_tmp = NaN(mcN,1);

    parfor k = 1:mcN
        params_k = params;

        % 1) 为本次仿真生成“真实 q”（截断为正）
        q_true_k = q0_true + sigma_q * randn();
        if q_true_k <= 0
            q_true_k = eps; % 或者用 abs(q_true_k)
        end
        params_k.q = q_true_k;

        % 2) 仿真 + 估计
        res = SimulateEPSCPeaks(params_k);
        est = estimate_synapse_params(res.epsc_peaks', params_k.noise_std);
        % 拟合TM模型
        fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);
        est.N = fitResult.A / est.q;
        % 3) 误差（默认 relative error；要 absolute 改下一行即可）
        nerr_tmp(k) = (est.N - N0_true);   % <-- absolute error
    end

    nerr_tmp = nerr_tmp(isfinite(nerr_tmp));
    nerr_all{si} = rmoutliers(nerr_tmp, 'mean', 'ThresholdFactor', 10);

    % scatter(qerr_all{si},1:length(qerr_all{si}))
    fprintf('σq = %.3g pA finished (%d samples)\n', sigma_q, numel(nerr_tmp));
end

% -------------------- 绘图 --------------------
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

col_q = GetColor('n');
alpha_violin = 0.45;
width = 0.2;

for si = 1:nSigma
    x0 = sigmaQList(si);
    data = nerr_all{si}(:);

    if numel(data) < 10
        continue;
    end

    [f,xi] = ksdensity(data);
    f = f ./ max(f) * width;

    X = transpose([x0 + f, fliplr(x0 - f)]);
    Y = [xi'; flipud(xi')];

    fill(X,Y,col_q, ...
        'FaceAlpha',alpha_violin, ...
        'EdgeColor','none');

    % 中心点（和你们原图一致：黑点画 mean）
    plot(x0, mean(data), 'k.', 'MarkerSize',14);
end

% 均值轨迹
qerr_mean = cellfun(@mean, nerr_all);
plot(sigmaQList, qerr_mean, 'k-', 'LineWidth',2);

xlabel('\sigma_q (pA)');
ylabel('N estimation error');   % 若是 relative error，可改成 'Relative error of q'
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
box on;
grid on;
ax = gca;
ax.GridAlpha = 0.15;

title('q-variability-dependent error of N estimation');

% y 轴范围（保持你们原来的 percentile 逻辑）
all_data = vertcat(nerr_all{:});
all_data = all_data(isfinite(all_data));
ylims = prctile(all_data, [1, 99]);
if ylims(1) == ylims(2)
    ylims = ylims + [-0.1, 0.1];
end
ylim(ylims);

saveFigureTransparent(figureHandle, 'fig5d');
close all;



%% ------------------------------------------------------------------------
% Fig5e. 改变 sweep 数量 T 对 q 估计的影响
% 3D orthographic violin plot (x=T, y=estimated q)
% Nature-style, minimal, publication-ready

clear; clc;

%-------------------- 参数设置 --------------------
TList = [5 10 20 30 50 80 120 200 300 500 800 1000];   % sweep数量（你可按需要改）
nT    = numel(TList);
mcN   = 200;                                           % 每个 T 的 Monte Carlo 次数（建议>=100）

params0 = GetDemoCellParams();                         % 基础参数（含 q,N,stim_freq,noise_std 等）
% 固定其它噪声/机制参数，只改 sweep 数量
% params0.noise_std = params0.noise_std;               % 若要固定为某个值，在这里手动指定

% 真值 q（用于画参考线，可选）
n_true = NaN;
if isfield(params0,'q_true'), n_true = params0.q_true; end
if isnan(n_true) && isfield(params0,'q0'), n_true = params0.q0; end
if isnan(n_true) && isfield(params0,'q'),  n_true = params0.q;  end

% 存储
q_all = cell(nT,1);

fprintf('Running Monte Carlo simulation (sweep number T)...\n');

for ti = 1:nT
    params = params0;
    params.num_sweeps = TList(ti);

    q_tmp = NaN(mcN,1);

    parfor k = 1:mcN
        % 1) 仿真
        res = SimulateEPSCPeaks(params);

        % 2) 估计
        est = estimate_synapse_params(res.epsc_peaks', params.noise_std);

        q_tmp(k) = est.q;
    end

    % 清理：NaN/Inf + 去异常（与其它图一致，阈值可改）
    q_tmp = q_tmp(isfinite(q_tmp));
    q_tmp = rmoutliers(q_tmp, 'mean', 'ThresholdFactor', 10);

    q_all{ti} = q_tmp(:);

    fprintf('T = %d sweeps finished (%d samples)\n', TList(ti), numel(q_tmp));
end

%-------------------- 绘图 --------------------
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

col_q = GetColor('q');
alpha_violin = 0.45;

% 伪x坐标：连续整数（你要0,1,2...就用 (0:nT-1)，要1,2,3...就用 (1:nT)）
xPlot = 0:(nT-1);             % <- 按你的要求：0,1,2,3...
baseWidth = 0.38;             % 小提琴固定宽度（等间距后手动给一个即可）

for ti = 1:nT
    x0 = xPlot(ti);
    data = q_all{ti};

    if numel(data) < 10
        continue;
    end

    [f,xi] = ksdensity(data);
    if all(f==0) || all(~isfinite(f))
        continue;
    end

    f = f ./ max(f) * baseWidth;

    X = transpose([x0 + f, fliplr(x0 - f)]);
    Y = [xi'; flipud(xi')];

    fill(X, Y, col_q, ...
        'FaceAlpha', alpha_violin, ...
        'EdgeColor', 'none');

    % 黑点：均值
    plot(x0, mean(data), 'k.', 'MarkerSize', 14);
end

% 均值轨迹（用伪x坐标连线）
q_mean = cellfun(@mean, q_all);
plot(xPlot, q_mean, 'k-', 'LineWidth', 2);

% 真值线（如果可用）
if ~isnan(n_true)
    yline(n_true, 'k--', sprintf('q_{true}=%.3g', n_true), ...
        'LineWidth', 1.6, ...
        'LabelHorizontalAlignment','left');
end

xlabel('Number of sweeps T');
ylabel('Estimated q');

set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
box on; grid on;
ax = gca; ax.GridAlpha = 0.15;

title('Sweep-number-dependent estimation of q');

% x轴：位置用伪坐标，但tick label显示真实TList
set(gca, 'XTick', xPlot);
set(gca, 'XTickLabel', string(TList));
xlim([min(xPlot)-0.8, max(xPlot)+0.8]);

% 如果标签太挤，可以旋转一点（可选）
% xtickangle(0);   % 不旋转
% xtickangle(45);  % 旋转45度

% y 轴范围：用 percentile 稳健截断
all_q_data = vertcat(q_all{:});
all_q_data = all_q_data(isfinite(all_q_data));
ylims = prctile(all_q_data, [0.5, 99.5]);
if ylims(1) == ylims(2)
    ylims = ylims + [-0.1, 0.1];
end
ylim(ylims);

%-------------------- 保存 --------------------
saveFigureTransparent(figureHandle, 'fig5e');
close all;




%% ------------------------------------------------------------------------
% Fig5d 改变 q 的 trial-to-trial 变异(σq) 对 N 估计误差的影响
% 3D orthographic violin plot
% Nature-style, minimal, publication-ready

clear; clc;

%-------------------- 参数设置 --------------------
sigmaQList = 0:0.5:5;              % q 的随机变异标准差 (pA) ——你按需要改范围
nSigma     = numel(sigmaQList);
mcN        = 200;

params0 = GetDemoCellParams();
params0.num_sweeps = 300;

% 固定测量噪声（如果你们仍想保留 measurement noise）
% params0.noise_std = 10;          % 例如固定 10 pA；若 GetDemoCellParams 已给定也可不动

q0_true = params0.q;               % baseline “真实” q
N0_true = params0.N;               % baseline “真实” N（本图只用来生成，但误差画 q）

% 存储：每个 σq 下的 q_error
nerr_all = cell(nSigma,1);

fprintf('Running Monte Carlo simulation (q variability)...\n');

for si = 1:nSigma
    params = params0;
    sigma_q = sigmaQList(si);

    nerr_tmp = NaN(mcN,1);

    parfor k = 1:mcN
        params_k = params;

        % 1) 为本次仿真生成“真实 q”（截断为正）
        q_true_k = q0_true + sigma_q * randn();
        if q_true_k <= 0
            q_true_k = eps; % 或者用 abs(q_true_k)
        end
        params_k.q = q_true_k;

        % 2) 仿真 + 估计
        res = SimulateEPSCPeaks(params_k);
        est = estimate_synapse_params(res.epsc_peaks', params_k.noise_std);
        % 拟合TM模型
        fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);
        est.N = fitResult.A / est.q;
        % 3) 误差（默认 relative error；要 absolute 改下一行即可）
        nerr_tmp(k) = (est.N - N0_true);   % <-- absolute error
    end

    nerr_tmp = nerr_tmp(isfinite(nerr_tmp));
    nerr_all{si} = rmoutliers(nerr_tmp, 'mean', 'ThresholdFactor', 10);

    % scatter(qerr_all{si},1:length(qerr_all{si}))
    fprintf('σq = %.3g pA finished (%d samples)\n', sigma_q, numel(nerr_tmp));
end

% -------------------- 绘图 --------------------
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

col_q = GetColor('n');
alpha_violin = 0.45;
width = 0.2;

for si = 1:nSigma
    x0 = sigmaQList(si);
    data = nerr_all{si}(:);

    if numel(data) < 10
        continue;
    end

    [f,xi] = ksdensity(data);
    f = f ./ max(f) * width;

    X = transpose([x0 + f, fliplr(x0 - f)]);
    Y = [xi'; flipud(xi')];

    fill(X,Y,col_q, ...
        'FaceAlpha',alpha_violin, ...
        'EdgeColor','none');

    % 中心点（和你们原图一致：黑点画 mean）
    plot(x0, mean(data), 'k.', 'MarkerSize',14);
end

% 均值轨迹
qerr_mean = cellfun(@mean, nerr_all);
plot(sigmaQList, qerr_mean, 'k-', 'LineWidth',2);

xlabel('\sigma_q (pA)');
ylabel('N estimation error');   % 若是 relative error，可改成 'Relative error of q'
set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
box on;
grid on;
ax = gca;
ax.GridAlpha = 0.15;

title('q-variability-dependent error of N estimation');

% y 轴范围（保持你们原来的 percentile 逻辑）
all_data = vertcat(nerr_all{:});
all_data = all_data(isfinite(all_data));
ylims = prctile(all_data, [1, 99]);
if ylims(1) == ylims(2)
    ylims = ylims + [-0.1, 0.1];
end
ylim(ylims);

saveFigureTransparent(figureHandle, 'fig5d');
close all;



%% ------------------------------------------------------------------------
% Fig5f. 改变 sweep 数量 T 对 N 估计的影响
% 3D orthographic violin plot (x=T, y=estimated N)
% Nature-style, minimal, publication-ready

clear; clc;

%-------------------- 参数设置 --------------------
TList = [5 10 20 30 50 80 120 200 300 500 800 1000];   % sweep数量（你可按需要改）
nT    = numel(TList);
mcN   = 200;                                           % 每个 T 的 Monte Carlo 次数（建议>=100）

params0 = GetDemoCellParams();                         % 基础参数（含 q,N,stim_freq,noise_std 等）
% 固定其它噪声/机制参数，只改 sweep 数量
% params0.noise_std = params0.noise_std;               % 若要固定为某个值，在这里手动指定

% 真值 N（用于画参考线，可选）
n_true = NaN;
if isfield(params0,'N_true'), n_true = params0.q_true; end
if isnan(n_true) && isfield(params0,'N0'), n_true = params0.N0; end
if isnan(n_true) && isfield(params0,'N'),  n_true = params0.N;  end

% 存储
n_all = cell(nT,1);

fprintf('Running Monte Carlo simulation (sweep number T)...\n');

for ti = 1:nT
    params = params0;
    params.num_sweeps = TList(ti);

    n_tmp = NaN(mcN,1);

    parfor k = 1:mcN
        % 1) 仿真
        res = SimulateEPSCPeaks(params);

        % 2) 估计
        est = estimate_synapse_params(res.epsc_peaks', params.noise_std);
        % 拟合TM模型
        fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);
        est.N = fitResult.A / est.q;
        n_tmp(k) = est.N;
    end

    % 清理：NaN/Inf + 去异常（与其它图一致，阈值可改）
    n_tmp = n_tmp(isfinite(n_tmp));
    n_tmp = rmoutliers(n_tmp, 'mean', 'ThresholdFactor', 10);

    n_all{ti} = n_tmp(:);

    fprintf('T = %d sweeps finished (%d samples)\n', TList(ti), numel(n_tmp));
end

%-------------------- 绘图 --------------------
figureHandle = figure('Position',[100, 100, 560, 420]);
hold on;

col_n = GetColor('n');
alpha_violin = 0.45;

% 伪x坐标：连续整数（你要0,1,2...就用 (0:nT-1)，要1,2,3...就用 (1:nT)）
xPlot = 0:(nT-1);             % <- 按你的要求：0,1,2,3...
baseWidth = 0.38;             % 小提琴固定宽度（等间距后手动给一个即可）

for ti = 1:nT
    x0 = xPlot(ti);
    data = n_all{ti};

    if numel(data) < 10
        continue;
    end

    [f,xi] = ksdensity(data);
    if all(f==0) || all(~isfinite(f))
        continue;
    end

    f = f ./ max(f) * baseWidth;

    X = transpose([x0 + f, fliplr(x0 - f)]);
    Y = [xi'; flipud(xi')];

    fill(X, Y, col_n, ...
        'FaceAlpha', alpha_violin, ...
        'EdgeColor', 'none');

    % 黑点：均值
    plot(x0, mean(data), 'k.', 'MarkerSize', 14);
end

% 均值轨迹（用伪x坐标连线）
n_mean = cellfun(@mean, n_all);
plot(xPlot, n_mean, 'k-', 'LineWidth', 2);

% 真值线（如果可用）
if ~isnan(n_true)
    yline(n_true, 'k--', sprintf('N_{true}=%.3g', n_true), ...
        'LineWidth', 1.6, ...
        'LabelHorizontalAlignment','left');
end

xlabel('Number of sweeps T');
ylabel('Estimated N');

set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
box on; grid on;
ax = gca; ax.GridAlpha = 0.15;

title('Sweep-number-dependent estimation of N');

% x轴：位置用伪坐标，但tick label显示真实TList
set(gca, 'XTick', xPlot);
set(gca, 'XTickLabel', string(TList));
xlim([min(xPlot)-0.8, max(xPlot)+0.8]);

% 如果标签太挤，可以旋转一点（可选）
% xtickangle(0);   % 不旋转
% xtickangle(45);  % 旋转45度

% y 轴范围：用 percentile 稳健截断
all_q_data = vertcat(n_all{:});
all_q_data = all_q_data(isfinite(all_q_data));
ylims = prctile(all_q_data, [1, 99]);
if ylims(1) == ylims(2)
    ylims = ylims + [-0.1, 0.1];
end
ylim(ylims);

%-------------------- 保存 --------------------
saveFigureTransparent(figureHandle, 'fig5f');
close all;



%% ------------------------------------------------------------------------
% Fig5g. 改变 sweep 数量 T 对 p_i 估计的影响
% 3D curve plot: X=T, Y=stimulus index, Z=estimated p_i sequence
% Each T corresponds to one curve in YZ plane, stacked along X.

clear; clc;

%-------------------- 参数设置 --------------------
TList = [5 10 20 30 50 80 120 200 300 500 800 1000];   % sweep数量（可改）
nT    = numel(TList);

mcN   = 200;          % 每个 T 的 Monte Carlo 次数（建议>=100）
outlierTF = 10;       % rmoutliers 阈值（可按需要调）

params0 = GetDemoCellParams();
nStim   = params0.num_stim;

%-------------------- （可选）计算 TM 真值 p_i --------------------
% 如果你不想画真值参考，把 showTrue = false 即可
showTrue = true;

% p_true = NaN(nStim,1);
if showTrue
    x_true = [params0.N * params0.q, ...
              params0.U, ...
              params0.tau_rec/1000, ...
              params0.tau_facil/1000];
    [~, R_true, u_true] = simulate_TM_phys(x_true, nStim, params0.stim_freq);
    % p_true = u_true .* R_true;
end

%-------------------- 存储：每个T对应一个“代表性 p_i 序列” --------------------
% p_meanSeq(:,ti): 第 ti 个 T 下的 p_i 序列（长度 nStim）
p_meanSeq  = NaN(nStim, nT);
p_upperSeq = NaN(nStim, nT);
p_lowerSeq = NaN(nStim, nT);

fprintf('Running Monte Carlo simulation (sweep number T -> p_i)...\n');

for ti = 1:nT
    params = params0;
    params.num_sweeps = TList(ti);

    % 存每次MC得到的完整 p 序列：nStim × mcN
    p_mc = NaN(nStim, mcN);

    parfor k = 1:mcN
        res = SimulateEPSCPeaks(params);
        est = estimate_synapse_params(res.epsc_peaks', params.noise_std);
        % 2)拟合TM模型
        fitResult = fit_TM_from_epsc(res.epsc_peaks, params.stim_freq);
        % 3) 根据 TM 的 A 得到 π_i
        % EPSC_mean = N * q * pi_i = A * pi_i
        % => pi_i = mean(EPSC)/A
        p_mc(:,k) = mean(res.epsc_peaks,1)' / fitResult.A;
    end

    % 清理：去掉 NaN/Inf
    p_mc(~isfinite(p_mc)) = NaN;
    p_mu = NaN(nStim,1);
    p_sd = NaN(nStim,1);

    % 对每个 stimulus i，在 MC 维度做 rmoutliers，然后取均值（或中位数）
    for i = 1:nStim
        tmp = p_mc(i,:);
        tmp = tmp(isfinite(tmp));
        if numel(tmp) < 10
            p_seq(i) = NaN;
            continue;
        end
        tmp = rmoutliers(tmp, 'mean', 'ThresholdFactor', outlierTF);

        % 代表性统计：mean / median 二选一
        p_mu(i) = mean(tmp);          % 均值
        p_sd(i) = std(tmp, 0);        % 标准差（和 Fig3a 一致）:contentReference[oaicite:1]{index=1}

    end

    p_meanSeq(:,ti)  = p_mu;
    p_upperSeq(:,ti) = p_mu + p_sd;
    p_lowerSeq(:,ti) = p_mu - p_sd;
    fprintf('T = %d sweeps finished (%d MC)\n', TList(ti), mcN);
end

%-------------------- 3D 绘图 --------------------
figureHandle = figure('Position',[100, 100, 1120, 420]);
hold on;

col_p = GetColor('p');
y = 1:nStim;

% 每个T画一条 3D 曲线：X 固定为 T，Y 为 stimulus index，Z 为 p_i
for ti = 1:nT
    x0 = ti;

    upper = p_upperSeq(:,ti)';
    lower = p_lowerSeq(:,ti)';

    if all(~isfinite(upper)) || all(~isfinite(lower))
        continue;
    end

    % 对 NaN 做简单处理：把非finite点剔除（避免 fill3 断裂报错）
    mask = isfinite(upper) & isfinite(lower);
    yy = y(mask);
    uu = upper(mask);
    ll = lower(mask);
    if numel(yy) < 3
        continue;
    end

    X = [x0*ones(size(yy)), x0*ones(size(yy))];
    Y = [yy, fliplr(yy)];
    Z = [uu, fliplr(ll)];

    fill3(X, Y, Z, [0.7 0.7 0.7], ...   % 灰色阴影（同 Fig3a）:contentReference[oaicite:2]{index=2}
        'EdgeColor','none', ...
        'FaceAlpha',0.4);
end

% ===== 再画每个 T 的均值曲线（紫色） =====
for ti = 1:nT
    x = ti * ones(size(y));
    z = p_meanSeq(:,ti)';

    plot3(x, y, z, '-', 'Color', col_p, 'LineWidth', 1.8);
end

% （可选）画 TM 真值参考：放在 x = min(TList)-delta 的平面上
if showTrue && all(isfinite(p_true))
    x0 = zeros(size(y));
    plot3(x0, y, p_true(:)', 'k--', 'LineWidth', 2.0);
end

% 坐标轴与美化
box on; grid on;
set(gca,'XTick', 1:nT);
set(gca,'XTickLabel', string(TList));
xlabel('Number of sweeps T');
ylabel('Stimulus Number i');
zlabel('Estimated p_i');

title('Sweep-number-dependent estimation of p_i (3D stacked sequences)');

set(gca,'FontName','Arial','FontSize',12,'LineWidth',1.1);
ax = gca; ax.GridAlpha = 0.15;

% 视角：让“YZ 平面曲线 + 沿 X 堆叠”更直观
view(22.5,53);

% X 轴范围与刻度（可选：按真实 T 显示）
% xlim([min(TList)-0.12*(max(TList)-min(TList)), max(TList)+0.05*(max(TList)-min(TList))]);
% set(gca,'XTick', TList);

% 如果 T 太密，可以只显示部分 tick
% set(gca,'XTick', TList(1:2:end));

% Z 范围稳健截断（可选）
% all_p = p_meanSeq(:);
% all_p = all_p(isfinite(all_p));
% if ~isempty(all_p)
%     zlims = prctile(all_p, [0.5 99.5]);
%     if zlims(1) == zlims(2)
%         zlims = zlims + [-0.01 0.01];
%     end
%     zlim(zlims);
% end

hold off;

%-------------------- 保存 --------------------
saveFigureTransparent(figureHandle, 'fig5g');
close all;

